@echo off
chcp 65001 >nul
title Compilando Maos VR
echo.
echo === Compilando o mod Maos VR ===
echo (na primeira vez baixa umas coisas, demora uns minutos. Precisa de internet e Java 17 ou mais novo)
echo.
where java >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Java nao encontrado. Instale o JDK 17: https://adoptium.net  e rode este arquivo de novo.
  pause
  exit /b 1
)
call gradlew.bat build
if errorlevel 1 (
  echo.
  echo [ERRO] Deu erro. Tire print dessa tela e mande pro Claude.
  pause
  exit /b 1
)
for %%f in (build\libs\maos-vr-*.jar) do (
  echo %%f | findstr /i "sources dev" >nul || copy /y "%%f" "maos-vr.jar" >nul
)
echo.
echo === PRONTO! O arquivo maos-vr.jar esta nesta pasta. ===
echo Coloque ele na pasta mods junto com o Fabric API.
pause
