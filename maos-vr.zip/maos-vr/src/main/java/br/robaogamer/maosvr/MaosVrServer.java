package br.robaogamer.maosvr;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Lado do servidor: recebe a posição das mãos de um jogador e repassa pros outros jogadores
 * que estão perto. Só funciona se o mod estiver instalado no servidor (ou no mundo LAN do anfitrião).
 */
public class MaosVrServer implements ModInitializer {
    @Override
    public void onInitialize() {
        ServerPlayNetworking.registerGlobalReceiver(MaosVrNet.CANAL, (server, player, handler, buf, sender) -> {
            boolean ativo = buf.readBoolean();
            int ativa = buf.readByte();
            float a = buf.readFloat(), b = buf.readFloat(), c = buf.readFloat(), d = buf.readFloat();

            server.execute(() -> {
                for (ServerPlayerEntity outro : server.getPlayerManager().getPlayerList()) {
                    if (outro == player) continue;
                    if (outro.world != player.world) continue;
                    if (outro.squaredDistanceTo(player) > 128 * 128) continue;
                    if (!ServerPlayNetworking.canSend(outro, MaosVrNet.CANAL)) continue;

                    PacketByteBuf out = PacketByteBufs.create();
                    out.writeUuid(player.getUuid());
                    out.writeBoolean(ativo);
                    out.writeByte(ativa);
                    out.writeFloat(a);
                    out.writeFloat(b);
                    out.writeFloat(c);
                    out.writeFloat(d);
                    ServerPlayNetworking.send(outro, MaosVrNet.CANAL, out);
                }
            });
        });
    }
}
