package br.robaogamer.maosvr;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.model.json.ModelTransformation;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.item.ItemStack;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

public class MaosVrMod implements ClientModInitializer {

    // ---------- estado ----------
    public static boolean ativo = false;
    public static int maoAtiva = 1; // 0 = esquerda, 1 = direita
    // posição de cada mão na tela, de -1 a 1 (0,0 = centro da tela)
    public static final double[] hx = {-0.35, 0.35};
    public static final double[] hy = {-0.15, -0.15};

    // ---------- ajustes (mexe aqui se quiser) ----------
    private static final double SENS_MOUSE = 0.0035;   // quanto o mouse move a mão
    private static final double VEL_SETAS = 0.03;      // quanto as setas movem a mão por tick
    private static final double ZONA_MORTA = 0.55;     // depois disso a câmera começa a seguir a mão
    private static final double VEL_CAM_X = 150;       // graus por segundo (horizontal)
    private static final double VEL_CAM_Y = 110;       // graus por segundo (vertical)

    private static KeyBinding teclaH;
    private static KeyBinding teclaZ;
    private static long ultimoFrame = 0;

    @Override
    public void onInitializeClient() {
        teclaH = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.maosvr.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "category.maosvr"));
        teclaZ = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.maosvr.trocar", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, "category.maosvr"));

        ClientTickEvents.START_CLIENT_TICK.register(this::aplicarMiraDaMao);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);

        // câmera seguindo a mão (por frame, pra ficar suave)
        WorldRenderEvents.START.register(ctx -> seguirComCamera());

        // mãos 3D com a skin do jogador
        WorldRenderEvents.LAST.register(ctx -> desenharMaos3D());

        // mira acompanhando a mão
        HudRenderCallback.EVENT.register((matrices, delta) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (!ativo || mc.currentScreen != null || mc.player == null || mc.options.hudHidden) return;
            int w = mc.getWindow().getScaledWidth();
            int h = mc.getWindow().getScaledHeight();
            for (int i = 0; i < 2; i++) {
                int x = (int) (w / 2.0 + hx[i] * (w / 2.0));
                int y = (int) (h / 2.0 - hy[i] * (h / 2.0));
                desenharMira(matrices, x, y, i == maoAtiva);
            }
        });

        // dentro do inventário / crafting a mão vira o cursor
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) ->
                ScreenEvents.afterRender(screen).register((s, matrices, mouseX, mouseY, delta) -> {
                    if (ativo) desenharMaoCursor(matrices, mouseX, mouseY);
                }));
    }

    // chamado pelo mixin quando o mouse mexe
    public static void moverMao(double dx, double dy) {
        hx[maoAtiva] = MathHelper.clamp(hx[maoAtiva] + dx * SENS_MOUSE, -0.95, 0.95);
        hy[maoAtiva] = MathHelper.clamp(hy[maoAtiva] - dy * SENS_MOUSE, -0.95, 0.95);
    }

    // ---------------------------------------------------------------- tick
    private void tick(MinecraftClient mc) {
        while (teclaH.wasPressed()) {
            ativo = !ativo;
            if (mc.player != null) {
                mc.player.sendMessage(Text.literal(ativo ? "Modo mãos: LIGADO" : "Modo mãos: DESLIGADO (jogando normal)"), true);
            }
        }
        while (teclaZ.wasPressed()) {
            if (ativo) {
                maoAtiva = 1 - maoAtiva;
                if (mc.player != null) {
                    mc.player.sendMessage(Text.literal(maoAtiva == 0 ? "Mão esquerda" : "Mão direita"), true);
                }
            }
        }

        // esconde a mão normal do jogo só enquanto o modo está ligado
        mc.gameRenderer.setRenderHand(!ativo);

        if (!ativo) return;

        // trava na 1ª pessoa (sem F5 / 2ª / 3ª pessoa)
        if (mc.options.getPerspective() != Perspective.FIRST_PERSON) {
            mc.options.setPerspective(Perspective.FIRST_PERSON);
        }

        long janela = mc.getWindow().getHandle();
        boolean cima = InputUtil.isKeyPressed(janela, GLFW.GLFW_KEY_UP);
        boolean baixo = InputUtil.isKeyPressed(janela, GLFW.GLFW_KEY_DOWN);
        boolean esq = InputUtil.isKeyPressed(janela, GLFW.GLFW_KEY_LEFT);
        boolean dir = InputUtil.isKeyPressed(janela, GLFW.GLFW_KEY_RIGHT);

        if (mc.currentScreen == null) {
            // no jogo: setas também movem a mão ativa
            if (cima) hy[maoAtiva] += VEL_SETAS;
            if (baixo) hy[maoAtiva] -= VEL_SETAS;
            if (esq) hx[maoAtiva] -= VEL_SETAS;
            if (dir) hx[maoAtiva] += VEL_SETAS;
            hx[maoAtiva] = MathHelper.clamp(hx[maoAtiva], -0.95, 0.95);
            hy[maoAtiva] = MathHelper.clamp(hy[maoAtiva], -0.95, 0.95);
        } else {
            // em menus: setas movem o cursor (a mão)
            double passo = 12;
            double dx = (dir ? passo : 0) - (esq ? passo : 0);
            double dy = (baixo ? passo : 0) - (cima ? passo : 0);
            if (dx != 0 || dy != 0) {
                GLFW.glfwSetCursorPos(janela, mc.mouse.getX() + dx, mc.mouse.getY() + dy);
            }
        }
    }

    // ---------------------------------------------------------------- câmera
    private void seguirComCamera() {
        long agora = System.nanoTime();
        double dt = ultimoFrame == 0 ? 0 : Math.min(0.05, (agora - ultimoFrame) / 1_000_000_000.0);
        ultimoFrame = agora;

        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (!ativo || p == null || mc.currentScreen != null || dt == 0) return;

        double x = hx[maoAtiva];
        double y = hy[maoAtiva];
        float yaw = p.getYaw();
        float pitch = p.getPitch();

        if (Math.abs(x) > ZONA_MORTA) {
            yaw += (float) (Math.signum(x) * (Math.abs(x) - ZONA_MORTA) * VEL_CAM_X * dt);
        }
        if (Math.abs(y) > ZONA_MORTA) {
            pitch -= (float) (Math.signum(y) * (Math.abs(y) - ZONA_MORTA) * VEL_CAM_Y * dt);
        }
        pitch = MathHelper.clamp(pitch, -90f, 90f);

        p.setYaw(yaw);
        p.setPitch(pitch);
        p.prevYaw = yaw;
        p.prevPitch = pitch;
    }

    // ---------------------------------------------------------------- mira / raio
    /** Lança um raio da câmera passando pela posição da mão e troca o alvo do jogo por ele. */
    private void aplicarMiraDaMao(MinecraftClient mc) {
        if (!ativo || mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (mc.interactionManager == null) return;

        double nx = hx[maoAtiva];
        double ny = hy[maoAtiva];

        double fovV = Math.toRadians(mc.options.getFov().getValue());
        double aspecto = (double) mc.getWindow().getFramebufferWidth() / mc.getWindow().getFramebufferHeight();
        double tv = Math.tan(fovV / 2.0);

        float pitch = mc.player.getPitch();
        float yaw = mc.player.getYaw();
        Vec3d frente = Vec3d.fromPolar(pitch, yaw);
        Vec3d cima = Vec3d.fromPolar(pitch - 90f, yaw);
        Vec3d direita = frente.crossProduct(cima).multiply(-1).normalize();
        // (se a mão ficar espelhada na horizontal, tira o multiply(-1) acima)

        Vec3d dir = frente
                .add(direita.multiply(nx * tv * aspecto))
                .add(cima.multiply(ny * tv))
                .normalize();

        double alcance = mc.interactionManager.getReachDistance();
        Vec3d origem = mc.player.getCameraPosVec(1.0f);
        Vec3d fim = origem.add(dir.multiply(alcance));

        BlockHitResult hit = mc.world.raycast(new RaycastContext(
                origem, fim, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, mc.player));
        HitResult alvo;
        if (hit.getType() == HitResult.Type.BLOCK) {
            alvo = hit;
        } else {
            alvo = BlockHitResult.createMissed(fim, hit.getSide(), hit.getBlockPos());
        }

        // mobs / jogadores: o alcance de bater é menor que o de quebrar bloco
        double alcanceEntidade = mc.interactionManager.hasExtendedReach() ? 6.0 : 3.0;
        Vec3d fimEntidade = origem.add(dir.multiply(alcanceEntidade));
        Box caixa = mc.player.getBoundingBox().stretch(dir.multiply(alcanceEntidade)).expand(1.0, 1.0, 1.0);
        EntityHitResult ent = ProjectileUtil.raycast(mc.player, origem, fimEntidade, caixa,
                e -> !e.isSpectator() && e.canHit(), alcanceEntidade * alcanceEntidade);
        if (ent != null) {
            double distBloco = alvo.getType() == HitResult.Type.BLOCK
                    ? alvo.getPos().squaredDistanceTo(origem) : Double.MAX_VALUE;
            if (origem.squaredDistanceTo(ent.getPos()) < distBloco) {
                alvo = ent;
                mc.targetedEntity = ent.getEntity();
            }
        }
        mc.crosshairTarget = alvo;
    }

    // ---------------------------------------------------------------- mãos 3D
    private void desenharMaos3D() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!ativo || mc.player == null || mc.currentScreen != null || mc.options.hudHidden) return;

        Object r = mc.getEntityRenderDispatcher().getRenderer(mc.player);
        if (!(r instanceof PlayerEntityRenderer renderer)) return;

        double fovV = Math.toRadians(mc.options.getFov().getValue());
        double aspecto = (double) mc.getWindow().getFramebufferWidth() / mc.getWindow().getFramebufferHeight();
        double tv = Math.tan(fovV / 2.0);

        VertexConsumerProvider.Immediate vcp = mc.getBufferBuilders().getEntityVertexConsumers();

        // mãos sempre por cima do mundo
        RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, MinecraftClient.IS_SYSTEM_MAC);

        for (int i = 0; i < 2; i++) {
            boolean direita = (i == 1);

            // ponto que a mão aponta (1 bloco à frente da câmera, no espaço da tela)
            double px = hx[i] * tv * aspecto;
            double py = hy[i] * tv;
            double pz = -1.0;

            // base do braço (saindo de baixo da tela)
            double bx = direita ? 0.30 : -0.30;
            double by = -0.40;
            double bz = -0.35;

            double dx = px - bx;
            double dy = py - by;
            double dz = pz - bz;
            double comp = Math.sqrt(dx * dx + dy * dy + dz * dz);
            float yaw = (float) Math.toDegrees(-Math.atan2(dx, -dz));
            float pitch = (float) Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
            float escala = (float) (comp / 0.75); // braço tem 12px = 0,75 bloco: estica até a mira

            MatrixStack ms = new MatrixStack();
            ms.push();
            ms.translate(bx, by, bz);
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));

            // braço
            ms.push();
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90f)); // braço aponta pra frente
            ms.scale(1f, MathHelper.clamp(escala, 0.8f, 1.8f), 1f);
            ms.translate(direita ? 0.375 : -0.375, 0, 0); // centraliza o braço no eixo
            if (direita) {
                renderer.renderRightArm(ms, vcp, LightmapTextureManager.MAX_LIGHT_COORDINATE, mc.player);
            } else {
                renderer.renderLeftArm(ms, vcp, LightmapTextureManager.MAX_LIGHT_COORDINATE, mc.player);
            }
            ms.pop();

            // item 3D na ponta da mão (mão ativa = item da mão principal, outra = mão secundária)
            ItemStack item = (i == maoAtiva) ? mc.player.getMainHandStack() : mc.player.getOffHandStack();
            if (!item.isEmpty() && mc.world != null) {
                ModelTransformation.Mode modo = direita
                        ? ModelTransformation.Mode.FIRST_PERSON_RIGHT_HAND
                        : ModelTransformation.Mode.FIRST_PERSON_LEFT_HAND;
                ms.push();
                ms.translate(0, 0, -MathHelper.clamp(escala, 0.8f, 1.8f) * 0.7);
                mc.getItemRenderer().renderItem(mc.player, item, modo, !direita, ms, vcp, mc.world,
                        LightmapTextureManager.MAX_LIGHT_COORDINATE, OverlayTexture.DEFAULT_UV,
                        mc.player.getId() + i);
                ms.pop();
            }
            ms.pop();
        }
        vcp.draw();
    }

    // ---------------------------------------------------------------- HUD
    private static void desenharMira(MatrixStack m, int x, int y, boolean ativa) {
        int cor = ativa ? 0xFFFFFFFF : 0x66FFFFFF;
        int sombra = ativa ? 0xAA000000 : 0x33000000;
        int t = ativa ? 5 : 2;
        // sombra
        DrawableHelper.fill(m, x - t - 1, y - 1, x + t + 2, y + 2, sombra);
        DrawableHelper.fill(m, x - 1, y - t - 1, x + 2, y + t + 2, sombra);
        // cruz
        DrawableHelper.fill(m, x - t, y, x + t + 1, y + 1, cor);
        DrawableHelper.fill(m, x, y - t, x + 1, y + t + 1, cor);
    }

    /** Mãozinha simples usada como cursor em inventários. */
    private static void desenharMaoCursor(MatrixStack m, int x, int y) {
        int pele = 0xFFF1C27D;
        int sombra = 0xFF8D5524;
        DrawableHelper.fill(m, x - 1, y - 1, x + 13, y + 14, 0xFFFFFFFF);
        DrawableHelper.fill(m, x, y, x + 12, y + 13, pele);
        for (int i = 0; i < 4; i++) {
            DrawableHelper.fill(m, x + i * 3, y - 5, x + i * 3 + 2, y, pele);
        }
        DrawableHelper.fill(m, x, y + 11, x + 12, y + 13, sombra);
    }
}
