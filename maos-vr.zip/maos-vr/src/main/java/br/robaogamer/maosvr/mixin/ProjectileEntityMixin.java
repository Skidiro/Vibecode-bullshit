package br.robaogamer.maosvr.mixin;

import br.robaogamer.maosvr.MaosVrServer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Lado do SERVIDOR: o projétil nasce na ponta da mão do jogador (que o servidor conferiu), não no olho. */
@Mixin(ProjectileEntity.class)
public abstract class ProjectileEntityMixin {
    @Inject(method = "setVelocity(Lnet/minecraft/entity/Entity;FFFFF)V", at = @At("TAIL"), require = 0)
    private void maosvr$nascerNaMao(Entity shooter, float pitch, float yaw, float roll, float speed,
                                    float divergence, CallbackInfo ci) {
        if (!(shooter instanceof ServerPlayerEntity sp)) return;
        Vec3d off = MaosVrServer.origemOffset(sp);
        if (off == null) return;
        Entity self = (Entity) (Object) this;
        self.setPosition(self.getX() + off.x, self.getY() + off.y, self.getZ() + off.z);
    }
}
