package br.robaogamer.maosvr;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

/**
 * Escalada com as Garras de Escalada.
 * Com uma garra em qualquer mão e a mira da mão apontando pra uma parede perto:
 * PULAR sobe, AGACHAR desce devagar, sem apertar nada você fica pendurado.
 */
public class MaosVrEscalada {

    private static final double ALCANCE = 2.5;        // distância máxima da mira até o bloco
    private static final double DIST_PAREDE = 1.0;    // distância horizontal máxima do corpo até a parede
    private static final double VEL_SUBIR = 0.20;
    private static final double VEL_DESCER = -0.10;

    private static int paradoTicks = 0;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || !MaosVrMod.ativo) { paradoTicks = 0; return; }
        if (p.isSpectator() || p.getAbilities().flying || p.isTouchingWater() || p.hasVehicle()) return;

        boolean temGarra = p.getMainHandStack().isOf(MaosVrItens.GARRAS) || p.getOffHandStack().isOf(MaosVrItens.GARRAS);
        if (!temGarra) { paradoTicks = 0; return; }

        // a mira das mãos (mesmo alvo usado pra quebrar bloco)
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) { paradoTicks = 0; return; }
        if (!hit.getSide().getAxis().isHorizontal()) { paradoTicks = 0; return; } // só parede, não chão/teto

        Vec3d olho = p.getCameraPosVec(1.0f);
        if (hit.getPos().squaredDistanceTo(olho) > ALCANCE * ALCANCE) { paradoTicks = 0; return; }

        double dx = hit.getPos().x - p.getX();
        double dz = hit.getPos().z - p.getZ();
        double distH = Math.sqrt(dx * dx + dz * dz);
        if (distH > DIST_PAREDE) { paradoTicks = 0; return; }

        // cola na parede (evita ficar flutuando longe, que servidores não gostam)
        double puxa = distH > 0.45 ? 0.06 : 0.0;
        double vx = distH > 0.001 ? dx / distH * puxa : 0;
        double vz = distH > 0.001 ? dz / distH * puxa : 0;

        double vy;
        if (mc.options.jumpKey.isPressed()) { vy = VEL_SUBIR; paradoTicks = 0; }
        else if (mc.options.sneakKey.isPressed()) { vy = VEL_DESCER; paradoTicks = 0; }
        else {
            vy = 0.0;
            // pendurado parado: de vez em quando escorrega um tiquinho, senão servidor com
            // "fly desligado" acha que você está voando e te expulsa depois de uns 4 segundos
            if (++paradoTicks >= 30) { vy = -0.1; paradoTicks = 0; }
        }

        p.setVelocity(vx, vy, vz);
        p.fallDistance = 0;
    }
}
