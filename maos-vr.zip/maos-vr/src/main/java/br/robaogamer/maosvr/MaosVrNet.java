package br.robaogamer.maosvr;

import net.minecraft.util.Identifier;

/** Canal de rede usado pra os jogadores verem as mãos uns dos outros. */
public class MaosVrNet {
    public static final Identifier CANAL = new Identifier("maosvr", "maos");
    /** Cliente -> servidor: "me teleporta pra essa posição" (TP do modo mãos). */
    public static final Identifier TP = new Identifier("maosvr", "tp");
    /** Cliente -> servidor: "estou inclinado assim" (o servidor confere). */
    public static final Identifier LEAN = new Identifier("maosvr", "lean");
    /** Servidor -> outros jogadores: inclinação já conferida de alguém. */
    public static final Identifier LEAN_PUB = new Identifier("maosvr", "lean_pub");
    /** Servidor -> dono: "essa inclinação não vale, usa essa". */
    /** Cliente -> servidor: "o próximo projétil nasce aqui" (deslocamento do olho até a ponta da mão). */
    public static final Identifier ORIGEM = new Identifier("maosvr", "origem");
    public static final Identifier LEAN_OK = new Identifier("maosvr", "lean_ok");
}
