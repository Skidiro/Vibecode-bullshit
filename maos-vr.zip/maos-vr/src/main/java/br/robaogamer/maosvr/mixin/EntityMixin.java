package br.robaogamer.maosvr.mixin;

import br.robaogamer.maosvr.MaosVrMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityMixin {
    // Enquanto a tecla de segurar (X) estiver apertada, o mouse move a mão e a câmera fica parada.
    // Soltou a tecla: a câmera volta ao normal e a mão fica onde parou.
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void maosvr$mouseMoveAMao(double dx, double dy, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.player == (Object) this && MaosVrMod.segurando()) {
            MaosVrMod.moverMao(dx, dy);
            ci.cancel();
        }
    }
}
