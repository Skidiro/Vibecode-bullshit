package com.vrhands;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;

public class VrHandsClient implements ClientModInitializer {
    public static volatile boolean serverHasMod = false;

    private static boolean prevH, prevZ, prevY, prevF, prevUse;
    private static boolean cameraSaved;
    private static boolean scrollInit;
    private static BlockPos breakingPos;
    private static int swingCounter;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(VrHandsClient::tick);
        WorldRenderEvents.LAST.register(HandRenderer::render);
        ClientPlayNetworking.registerGlobalReceiver(VrHandsServer.HELLO,
                (client, handler, buf, sender) -> serverHasMod = true);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> serverHasMod = false);
    }

    // Anula os cliques normais do Minecraft enquanto as maos controlam a mira,
    // senao o jogo age no bloco do crosshair central ao MESMO tempo.
    public static boolean suppressVanillaClicks() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return HandState.enabled
                && (HandState.bothHands || HandState.singleHand)
                && mc.player != null
                && mc.interactionManager != null
                && !mc.player.isSpectator()
                && mc.currentScreen == null;
    }

    private static boolean key(long win, int k) {
        return GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
    }

    private static void initScroll(MinecraftClient mc) {
        if (scrollInit || mc.getWindow() == null) return;
        GLFW.glfwSetScrollCallback(mc.getWindow().getHandle(), (win, xo, yo) -> {
            if (!HandState.enabled) return;
            if (!HandState.bothHands && !HandState.singleHand) return;
            float d = (float) -yo * 0.15f;
            if (HandState.singleHand && !HandState.bothHands) {
                HandPhysics.tryMove(mc, HandState.off(HandState.activeHand), 0, 0, d);
            } else {
                HandPhysics.tryMove(mc, HandState.left, 0, 0, d);
                HandPhysics.tryMove(mc, HandState.right, 0, 0, d);
            }
        });
        scrollInit = true;
    }

    private static void tick(MinecraftClient mc) {
        initScroll(mc);
        long win = mc.getWindow() == null ? 0 : mc.getWindow().getHandle();
        boolean h = win != 0 && key(win, GLFW_KEY_H);
        boolean z = win != 0 && key(win, GLFW_KEY_Z);
        boolean y = win != 0 && key(win, GLFW_KEY_Y);
        boolean f = win != 0 && key(win, GLFW_KEY_F);
        boolean x = win != 0 && key(win, GLFW_KEY_X);

        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.isPaused()) {
            prevH = h; prevZ = z; prevY = y; prevF = f;
            if (mc.player == null) {
                cameraSaved = false;
                breakingPos = null;
                HandState.bothHands = HandState.singleHand = HandState.crawling = false;
                HandState.leftMira = HandState.rightMira = false;
                HandState.tpSelecting = false;
            }
            return;
        }

        // ---- toggles ----
        if (h && !prevH) {
            HandState.enabled = !HandState.enabled;
            if (HandState.enabled) mc.options.setPerspective(Perspective.FIRST_PERSON);
        }
        if (z && !prevZ) HandState.activeHand = 1 - HandState.activeHand; // troca de mao
        if (y && !prevY) {
            HandState.crawlEnabled = !HandState.crawlEnabled;
            if (!HandState.crawlEnabled) setCrawling(mc, false);
        }
        prevH = h; prevZ = z; prevY = y;

        if (!HandState.enabled) {
            cameraSaved = false;
            HandState.bothHands = HandState.singleHand = false;
            HandState.leftMira = HandState.rightMira = false;
            HandState.tpSelecting = false;
            stopBreaking(mc);
            prevF = f;
            return;
        }

        // trava em 1a pessoa
        if (mc.options.getPerspective() != Perspective.FIRST_PERSON) {
            mc.options.setPerspective(Perspective.FIRST_PERSON);
        }

        HandState.bothHands = x && !z;
        HandState.singleHand = z;
        boolean mouseMode = x || z;
        boolean arrows = key(win, GLFW_KEY_LEFT) || key(win, GLFW_KEY_RIGHT)
                || key(win, GLFW_KEY_UP) || key(win, GLFW_KEY_DOWN);

        if (!mouseMode) {
            cameraSaved = false;
            HandState.leftMira = HandState.rightMira = false;
            HandState.tpSelecting = false;
            stopBreaking(mc);
            prevF = f;
            return;
        }

        // ---- camera travada + maos pelo mouse ----
        if (!cameraSaved) {
            HandState.savedYaw = mc.player.getYaw();
            HandState.savedPitch = mc.player.getPitch();
            double[] cx = new double[1], cy = new double[1];
            GLFW.glfwGetCursorPos(win, cx, cy);
            HandState.lastX = cx[0];
            HandState.lastY = cy[0];
            cameraSaved = true;
        }
        double[] cx = new double[1], cy = new double[1];
        GLFW.glfwGetCursorPos(win, cx, cy);
        float dx = (float) (cx[0] - HandState.lastX) * 0.003f;
        float dy = (float) (cy[0] - HandState.lastY) * 0.003f;
        HandState.lastX = cx[0];
        HandState.lastY = cy[0];

        // move as maos controladas (com fisica: nao atravessam blocos)
        if (HandState.singleHand) {
            HandPhysics.tryMove(mc, HandState.off(HandState.activeHand), dx, -dy, 0);
        } else {
            HandPhysics.tryMove(mc, HandState.left, dx, -dy, 0);
            HandPhysics.tryMove(mc, HandState.right, dx, -dy, 0);
        }

        // numpad controla a camera
        if (key(win, GLFW_KEY_KP_4)) HandState.savedYaw -= 4f;
        if (key(win, GLFW_KEY_KP_6)) HandState.savedYaw += 4f;
        if (key(win, GLFW_KEY_KP_8)) HandState.savedPitch -= 4f;
        if (key(win, GLFW_KEY_KP_2)) HandState.savedPitch += 4f;
        HandState.savedPitch = Math.max(-89f, Math.min(89f, HandState.savedPitch));
        mc.player.setYaw(HandState.savedYaw);
        mc.player.setPitch(HandState.savedPitch);
        mc.player.prevYaw = HandState.savedYaw;
        mc.player.prevPitch = HandState.savedPitch;

        // setas mexem a segunda mao
        float step = 0.06f;
        float sx = 0, sy = 0;
        if (key(win, GLFW_KEY_LEFT)) sx -= step;
        if (key(win, GLFW_KEY_RIGHT)) sx += step;
        if (key(win, GLFW_KEY_DOWN)) sy -= step;
        if (key(win, GLFW_KEY_UP)) sy += step;
        if (sx != 0 || sy != 0) HandPhysics.tryMove(mc, HandState.off(1 - HandState.activeHand), sx, sy, 0);

        // ---- CRAWL estilo VR (precisa do mod no servidor, ou singleplayer) ----
        boolean crawlAllowed = serverHasMod || mc.isIntegratedServerRunning();
        boolean wantCrawl = HandState.crawlEnabled && mc.player.isSneaking() && crawlAllowed;
        if (wantCrawl != HandState.crawling) setCrawling(mc, wantCrawl);
        if (HandState.crawling) {
            // teclado nao anda: so arrastando com as 2 maos
            mc.player.input.movementForward = 0;
            mc.player.input.movementSideways = 0;
            mc.player.input.jumping = false;
            if (HandState.bothHands) {
                Vec3d avg = avgCenter(mc);
                Vec3d to = avg.subtract(mc.player.getPos());
                to = new Vec3d(to.x, 0, to.z);
                double dist = to.length();
                if (dist > 0.9) {
                    Vec3d vel = to.normalize().multiply(Math.min(0.09, (dist - 0.9) * 0.12));
                    mc.player.setVelocity(vel.x, mc.player.getVelocity().y, vel.z);
                }
            }
        }

        // ---- ESCALADA (item + modo das 2 maos + X) ----
        boolean holdingClaw = isClaw(mc.player.getMainHandStack()) || isClaw(mc.player.getOffHandStack());
        HandState.climbing = HandState.bothHands && holdingClaw;
        HandState.anchoredL = HandState.climbing && HandPhysics.touchesSolid(mc, HandState.left);
        HandState.anchoredR = HandState.climbing && HandPhysics.touchesSolid(mc, HandState.right);
        if (HandState.climbing && (HandState.anchoredL || HandState.anchoredR)) {
            double yawRad = Math.toRadians(mc.player.getYaw());
            Vec3d right = new Vec3d(-Math.cos(yawRad), 0, -Math.sin(yawRad));
            Vec3d vel = mc.player.getVelocity()
                    .add(right.multiply(dx * 1.2))
                    .add(0, -dy * 1.6, 0);
            mc.player.setVelocity(vel);
            mc.player.fallDistance = 0;
        }

        // ---- MIRAS: cada mao mira no seu proprio bloco ----
        if (HandState.bothHands) {
            HandState.setTarget(0, aim(mc, 0));
            HandState.setTarget(1, aim(mc, 1));
            HandState.leftMira = true;
            HandState.rightMira = true;
        } else {
            int ah = 1 - HandState.activeHand; // mao das setas
            if (arrows) HandState.setTarget(ah, aim(mc, ah));
            // mao do mouse NAO mira (so move); a mira da outra so aparece com seta apertada
            HandState.leftMira = (ah == 0) && arrows;
            HandState.rightMira = (ah == 1) && arrows;
        }
        HandState.decayTargets();

        // F tambem troca item para a mao secundaria no vanilla;
        // drena a fila de cliques pra nao spammar a troca (ideal: remapear essa tecla)
        if (HandState.bothHands) {
            while (mc.options.swapHandsKey.wasPressed()) { }
        }

        handleClicks(mc);

        // ---- TELEPORTE (só com X / duas maos) ----
        if (f) {
            if (HandState.bothHands) {
                HandState.tpTarget = computeTpTarget(mc);
                HandState.tpSelecting = true;
            }
        } else {
            if (prevF && HandState.tpSelecting && HandState.tpTarget != null) {
                Vec3d t = HandState.tpTarget;
                mc.player.setPosition(t.x, t.y, t.z);
                mc.player.setVelocity(Vec3d.ZERO);
                mc.player.fallDistance = 0;
            }
            HandState.tpSelecting = false;
        }
        prevF = f;
    }

    // ================= cliques =================

    private static void handleClicks(MinecraftClient mc) {
        boolean attack = mc.options.attackKey.isPressed();
        boolean use = mc.options.useKey.isPressed();
        boolean useEdge = use && !prevUse;
        prevUse = use;

        int attackHand, useHand;
        if (HandState.bothHands) {
            attackHand = 0; // LEFT click  -> mao ESQUERDA
            useHand = 1;    // RIGHT click -> mao DIREITA
        } else {
            attackHand = 1 - HandState.activeHand; // Z: cliques vao pra mao das setas
            useHand = attackHand;
        }

        BlockHitResult useTarget = HandState.target(useHand);
        if (useEdge && useTarget != null && useTarget.getType() == HitResult.Type.BLOCK) {
            ActionResult r = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, useTarget);
            if (r.isAccepted()) {
                mc.player.swingHand(Hand.MAIN_HAND);
            } else {
                var tr = mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                if (tr.getResult().isAccepted()) mc.player.swingHand(Hand.MAIN_HAND);
            }
        }

        BlockHitResult at = HandState.target(attackHand);
        if (attack && at != null && at.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = at.getBlockPos();
            if (!pos.equals(breakingPos)) {
                stopBreaking(mc);
                if (mc.interactionManager.attackBlock(pos, at.getSide())) {
                    breakingPos = pos;
                    mc.player.swingHand(Hand.MAIN_HAND);
                    swingCounter = 0;
                }
            } else {
                mc.interactionManager.updateBlockBreakingProgress(pos, at.getSide());
                if (++swingCounter % 4 == 0) mc.player.swingHand(Hand.MAIN_HAND);
            }
        } else {
            stopBreaking(mc);
        }
    }

    private static void stopBreaking(MinecraftClient mc) {
        if (breakingPos != null && mc.interactionManager != null) {
            mc.interactionManager.cancelBlockBreaking();
        }
        breakingPos = null;
    }

    // ================= utilidades =================

    private static BlockHitResult aim(MinecraftClient mc, int hand) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d c = HandPhysics.center(eye, mc.player.getYaw(), mc.player.getPitch(), HandState.off(hand));
        Vec3d dir = c.subtract(eye).normalize();
        Vec3d end = eye.add(dir.multiply(4.5));
        RaycastContext ctx = new RaycastContext(eye, end,
                RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, mc.player);
        return mc.world.raycast(ctx);
    }

    private static Vec3d avgCenter(MinecraftClient mc) {
        Vec3d eye = mc.player.getEyePos();
        double yaw = mc.player.getYaw(), pitch = mc.player.getPitch();
        Vec3d a = HandPhysics.center(eye, yaw, pitch, HandState.left);
        Vec3d b = HandPhysics.center(eye, yaw, pitch, HandState.right);
        return a.add(b).multiply(0.5);
    }

    private static Vec3d computeTpTarget(MinecraftClient mc) {
        Vec3d base = avgCenter(mc);
        double yawRad = Math.toRadians(mc.player.getYaw());
        Vec3d fwd = new Vec3d(-Math.sin(yawRad), 0, Math.cos(yawRad));
        BlockPos p0 = BlockPos.ofFloored(base.add(fwd.multiply(6)));
        for (int dy = 3; dy >= -6; dy--) {
            BlockPos p = p0.add(0, dy, 0);
            boolean ground = mc.world.getBlockState(p).isSolidBlock(mc.world, p);
            boolean air1 = mc.world.isAir(p.up());
            boolean air2 = mc.world.isAir(p.up(2));
            if (ground && air1 && air2) {
                return new Vec3d(p.getX() + 0.5, p.getY() + 1, p.getZ() + 0.5);
            }
        }
        return null;
    }

    private static void setCrawling(MinecraftClient mc, boolean v) {
        HandState.crawling = v;
        CrawlState.set(mc.player.getUuid(), v);
        if (ClientPlayNetworking.canSend(VrHandsServer.CRAWL)) {
            var buf = PacketByteBufs.create();
            buf.writeBoolean(v);
            ClientPlayNetworking.send(VrHandsServer.CRAWL, buf);
        }
    }

    private static boolean isClaw(ItemStack s) {
        return s.getItem() == VrHandsItems.CLIMBING_CLAW;
    }
}
