package br.robaogamer.maosvr.mixin;

import br.robaogamer.maosvr.MaosVrLean;
import br.robaogamer.maosvr.MaosVrMod;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {
    @Unique private boolean maosvr$pushed = false;

    // jogadores inclinados (que o SERVIDOR validou) aparecem tombados pra todo mundo
    @Inject(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"), require = 0)
    private void maosvr$inclinarAntes(LivingEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                                      VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        maosvr$pushed = false;
        float[] l = MaosVrMod.leanRemoto(entity.getUuid());
        if (l == null) return;
        double len = Math.hypot(l[0], l[1]);
        if (len < 0.02) return;
        double[] h = MaosVrLean.horizontal(l[0], l[1], entity.getYaw(tickDelta));
        double hl = Math.hypot(h[0], h[1]);
        if (hl < 1e-4) return;
        double theta = MaosVrLean.angulo(len);
        matrices.push();
        // gira em volta dos pés, na direção da inclinação
        matrices.multiply(new Quaternionf().rotationAxis((float) theta, (float) (h[1] / hl), 0f, (float) (-h[0] / hl)));
        maosvr$pushed = true;
    }

    @Inject(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("RETURN"), require = 0)
    private void maosvr$inclinarDepois(LivingEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                                       VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        if (maosvr$pushed) {
            matrices.pop();
            maosvr$pushed = false;
        }
    }
}
