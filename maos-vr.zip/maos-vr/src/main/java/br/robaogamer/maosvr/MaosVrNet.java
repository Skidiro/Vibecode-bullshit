package br.robaogamer.maosvr;

import net.minecraft.util.Identifier;

/** Canal de rede usado pra os jogadores verem as mãos uns dos outros. */
public class MaosVrNet {
    public static final Identifier CANAL = new Identifier("maosvr", "maos");
}
