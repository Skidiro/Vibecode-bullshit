# Mãos VR (Fabric, Minecraft 1.19.4)

Duas mãos 3D com a textura da SUA skin.

## Controles
- **H**: liga/desliga o modo (desligado = joga normal)
- **Z**: troca a mão que você controla
- **Mouse** (ou dedo na tela): move a mão ativa
- **Setinhas**: também movem a mão ativa
- **Botão esquerdo/direito**: quebra/usa onde a mão aponta (a mira fica em cima da mão)
- Quando a mão chega perto da borda, a **câmera gira sozinha** atrás dela
- Com o modo ligado a câmera fica travada na 1ª pessoa (sem F5)
- No inventário/crafting a mão vira o cursor

Dá pra mudar as teclas em Controles > "Mãos VR".

## Compilar (jeito mais fácil, sem GitHub)
1. Instala o **JDK 17** (grátis): adoptium.net (marca a opção de adicionar ao PATH).
2. Extrai o zip e **dá dois cliques em `COMPILAR.bat`** (Linux/Mac: `./COMPILAR.sh`).
3. Espera uns minutos. Quando acabar aparece **maos-vr.jar** na própria pasta.
   Se der erro, tira print da tela preta e manda pro Claude.

## Compilar pelo GitHub (alternativa)
Sobe os arquivos num repositório; a aba **Actions** compila e deixa o `.jar` em "Artifacts".
Com uma Release (tag `v1.0.0`) vira link público de download.

## Instalar (PC, PojavLauncher, FoldCraft Launcher)
1. Cria uma instalação **Fabric 1.19.4**.
2. Coloca o **Fabric API 1.19.4** e o **maos-vr.jar** na pasta `mods`.
3. No Pojav/FCL, mapeie **H**, **Z** e as **setas** nos controles. O dedo arrastando na tela move a mão.
