package com.vrhands.mixin;

import com.vrhands.CrawlState;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    // Forca a pose de crawl (1 bloco de altura) quando o jogador esta
    // agachado com o modo crawl do Y ativo. Funciona no multiplayer porque
    // roda no servidor tambem.
    @Inject(method = "updatePose", at = @At("HEAD"), cancellable = true)
    private void vrhands$crawlPose(CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self instanceof PlayerEntity p
                && p.isSneaking()
                && CrawlState.isCrawling(p.getUuid())) {
            p.setPose(EntityPose.CRAWLING);
            ci.cancel();
        }
    }
}
