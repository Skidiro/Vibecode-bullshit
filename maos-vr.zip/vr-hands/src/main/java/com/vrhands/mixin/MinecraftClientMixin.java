package com.vrhands.mixin;

import com.vrhands.VrHandsClient;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    // Impede que os cliques normais (crosshair central) acontecam junto
    // com os cliques das maos — senao da acao duplicada no bloco errado.
    @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
    private void vrhands$suppressAttack(CallbackInfoReturnable<Boolean> cir) {
        if (VrHandsClient.suppressVanillaClicks()) cir.setReturnValue(false);
    }

    @Inject(method = "doItemUse", at = @At("HEAD"), cancellable = true)
    private void vrhands$suppressUse(CallbackInfo ci) {
        if (VrHandsClient.suppressVanillaClicks()) ci.cancel();
    }

    @Inject(method = "handleBlockBreaking", at = @At("HEAD"), cancellable = true)
    private void vrhands$suppressBreak(boolean bl, CallbackInfo ci) {
        if (VrHandsClient.suppressVanillaClicks()) ci.cancel();
    }
}
