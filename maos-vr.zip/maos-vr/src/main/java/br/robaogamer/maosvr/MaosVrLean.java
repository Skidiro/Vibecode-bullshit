package br.robaogamer.maosvr;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Inclinar o corpo (estilo Minecraft VR). Código COMUM: o cliente usa pra responder rápido e o
 * servidor usa pra conferir (a cabeça não pode atravessar bloco, então ninguém espia através de parede).
 *
 * lx = pra direita (+) / esquerda (-), lz = pra frente (+) / trás (-), em blocos, relativos pra onde o jogador olha.
 */
public class MaosVrLean {
    public static final double MAX = 0.65;          // o quanto dá pra inclinar
    private static final double ALTURA_OLHO = 1.62;
    private static final double MEIA_CABECA = 0.2;  // a cabeça é um cubinho de 0,4

    /** Ângulo (rad) que o corpo inteiro tomba pra levar a cabeça até 'len' de distância. */
    public static double angulo(double len) {
        return Math.asin(Math.min(len / ALTURA_OLHO, 0.5));
    }

    /** Quanto a cabeça desce quando o corpo tomba (o corpo gira em volta dos pés). */
    public static double queda(double len) {
        return ALTURA_OLHO * (1.0 - Math.cos(angulo(len)));
    }

    /** Deslocamento horizontal no mundo (x, z) dado o lean e pra onde o jogador olha (yaw em graus). */
    public static double[] horizontal(double lx, double lz, float yawDeg) {
        double r = Math.toRadians(yawDeg);
        double fx = -Math.sin(r), fz = Math.cos(r);     // frente
        double rx = -Math.cos(r), rz = -Math.sin(r);    // direita
        return new double[]{rx * lx + fx * lz, rz * lx + fz * lz};
    }

    /** Deslocamento total da cabeça no mundo (inclui a descida). */
    public static Vec3d offsetMundo(double lx, double lz, float yawDeg) {
        double[] h = horizontal(lx, lz, yawDeg);
        return new Vec3d(h[0], -queda(Math.hypot(lx, lz)), h[1]);
    }

    /** Confere o lean: anda do corpo até o alvo e PARA antes de a cabeça bater em bloco. */
    public static float[] validar(World w, Entity e, float lx, float lz, float yawDeg) {
        double len = Math.hypot(lx, lz);
        if (!(len > 1e-4)) return new float[]{0f, 0f};
        double max = Math.min(len, MAX);
        double ux = lx / len, uz = lz / len;
        Vec3d olho = e.getEyePos();
        double ok = 0;
        for (double t = 0.05; t < max + 0.05; t += 0.05) {
            double tt = Math.min(t, max);
            Vec3d off = offsetMundo(ux * tt, uz * tt, yawDeg);
            double px = olho.x + off.x, py = olho.y + off.y, pz = olho.z + off.z;
            Box cabeca = new Box(px - MEIA_CABECA, py - MEIA_CABECA, pz - MEIA_CABECA,
                                 px + MEIA_CABECA, py + MEIA_CABECA, pz + MEIA_CABECA);
            if (w.getBlockCollisions(e, cabeca).iterator().hasNext()) break;
            ok = tt;
        }
        return new float[]{(float) (ux * ok), (float) (uz * ok)};
    }

    private static double[] rodar(double px, double py, double pz, double ax, double ay, double az, double th) {
        double c = Math.cos(th), sn = Math.sin(th), dot = ax * px + ay * py + az * pz;
        double cx = ay * pz - az * py, cy = az * px - ax * pz, cz = ax * py - ay * px;   // eixo x ponto
        return new double[]{px * c + cx * sn + ax * dot * (1 - c),
                            py * c + cy * sn + ay * dot * (1 - c),
                            pz * c + cz * sn + az * dot * (1 - c)};
    }

    /**
     * Quanto o ombro (lado = +1 direito, -1 esquerdo) muda de lugar em relação à cabeça quando o corpo
     * tomba. Retorna (direita, cima, frente) no referencial de quem olha reto (só o yaw).
     */
    public static double[] ombroDelta(double lx, double lz, double lado) {
        double len = Math.hypot(lx, lz);
        if (len < 1e-4) return new double[]{0, 0, 0};
        double th = angulo(len);
        double dr = lx / len, df = lz / len;
        double ax = df, ay = 0, az = -dr;                 // eixo: cima x direção do lean
        double[] olho = rodar(0, ALTURA_OLHO, 0, ax, ay, az, th);
        double[] ombro = rodar(lado * 0.31, 1.40, 0, ax, ay, az, th);
        return new double[]{(ombro[0] - olho[0]) - lado * 0.31, (ombro[1] - olho[1]) + 0.22, ombro[2] - olho[2]};
    }
}
