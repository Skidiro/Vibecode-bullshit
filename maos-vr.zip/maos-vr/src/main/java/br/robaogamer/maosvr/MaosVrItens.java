package br.robaogamer.maosvr;

import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/** Itens do mod. */
public class MaosVrItens {

    /** Garras de Escalada: segure uma (em qualquer mão) pra escalar paredes usando as mãos. */
    public static final Item GARRAS = new Item(new FabricItemSettings().maxCount(1));

    /** Roda no servidor e no cliente (entrada "main"). */
    public static void registrar() {
        Registry.register(Registries.ITEM, new Identifier("maosvr", "garras_escalada"), GARRAS);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(GARRAS));
    }

    /** Só no cliente: pinta a textura da tesoura do jogo de roxo. */
    public static void iniciarCliente() {
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> tintIndex == 0 ? 0xFFB05CFF : 0xFFFFFFFF, GARRAS);
    }
}
