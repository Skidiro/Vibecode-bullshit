package br.robaogamer.maosvr;

import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.json.Transformation;
import net.minecraft.item.FishingRodItem;
import net.minecraft.item.ToolItem;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.util.math.Direction;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.item.ItemStack;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

public class MaosVrMod implements ClientModInitializer {

    // ---------- estado ----------
    public static boolean ativo = false;
    public static int maoAtiva = 1; // 0 = esquerda, 1 = direita
    // modo 2 mãos juntas (tecla G, só funciona com o modo mãos ligado pelo H)
    public static boolean juntas = false;
    private static final double ESPACO = 0.18; // distância de cada mão até o centro, no modo juntas
    // posição de cada mão na tela, de -1 a 1 (0,0 = centro da tela)
    public static final double[] hx = {-0.35, 0.35};
    public static final double[] hy = {-0.15, -0.15};

    // ---------- ajustes (mexe aqui se quiser) ----------
    private static final double VEL_SETAS = 0.04;      // quanto as setas movem a mão por tick

    // ajuste fino da posição do item na mão (teclado numérico, dá pra remapear em Controles)
    public static double itemX = 0, itemY = 0, itemZ = 0;
    private static final double PASSO_ITEM = 0.004;

    private static KeyBinding teclaH;
    private static KeyBinding teclaZ;
    private static KeyBinding teclaG;
    private static KeyBinding teclaV;  // inventário na mão esquerda
    private static KeyBinding camEsq, camDir, camCima, camBaixo; // câmera pelo numpad
    private static KeyBinding teclaX; // SEGURAR: enquanto segura, o mouse move a mão (câmera parada)
    private static KeyBinding itemXm, itemXp, itemYp, itemYm, itemZm, itemZp;

    @Override
    public void onInitializeClient() {
        teclaH = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.maosvr.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "category.maosvr"));
        teclaZ = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.maosvr.trocar", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, "category.maosvr"));

        teclaG = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.maosvr.juntas", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.maosvr"));

        teclaV = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.maosvr.inventario", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.maosvr"));
        camEsq = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.maosvr.cam_esq", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_KP_4, "category.maosvr"));
        camDir = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.maosvr.cam_dir", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_KP_6, "category.maosvr"));
        camCima = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.maosvr.cam_cima", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_KP_8, "category.maosvr"));
        camBaixo = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.maosvr.cam_baixo", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_KP_2, "category.maosvr"));

        teclaX = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.maosvr.segurar", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, "category.maosvr"));

        itemXm = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.maosvr.item_x_menos", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.maosvr"));
        itemXp = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.maosvr.item_x_mais", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.maosvr"));
        itemYp = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.maosvr.item_y_mais", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.maosvr"));
        itemYm = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.maosvr.item_y_menos", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.maosvr"));
        itemZm = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.maosvr.item_z_menos", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.maosvr"));
        itemZp = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.maosvr.item_z_mais", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.maosvr"));

        MaosVrItens.iniciarCliente();

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);

        // mãos 3D com a skin do jogador
        WorldRenderEvents.LAST.register(ctx -> {
            desenharRemotas(ctx);   // mãos dos outros jogadores (multiplayer)
            desenharMaos3D();       // as suas mãos, por cima de tudo
        });

        // recebe o estado das mãos dos outros jogadores (o servidor repassa)
        ClientPlayNetworking.registerGlobalReceiver(MaosVrNet.CANAL, (client, handler, buf, sender) -> {
            UUID id = buf.readUuid();
            boolean at = buf.readBoolean();
            int ativaMao = buf.readByte();
            float a = buf.readFloat(), b = buf.readFloat(), c = buf.readFloat(), d = buf.readFloat();
            client.execute(() -> {
                Remoto r = remotos.computeIfAbsent(id, k -> new Remoto());
                r.ativo = at;
                r.ativa = ativaMao;
                r.tx[0] = a; r.ty[0] = b; r.tx[1] = c; r.ty[1] = d;
                if (r.novo) {
                    System.arraycopy(r.tx, 0, r.cx, 0, 2);
                    System.arraycopy(r.ty, 0, r.cy, 0, 2);
                    r.novo = false;
                }
                r.ultimo = System.currentTimeMillis();
            });
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> remotos.clear());

        // mira acompanhando a mão
        HudRenderCallback.EVENT.register((matrices, delta) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (!ativo || mc.currentScreen != null || mc.player == null || mc.options.hudHidden) return;
            int w = mc.getWindow().getScaledWidth();
            int h = mc.getWindow().getScaledHeight();
            if (painel) desenharPainel(matrices, mc, w, h);
            if (juntas) {
                // uma mira só, no meio das duas mãos
                int x = (int) (w / 2.0 + miraX() * (w / 2.0));
                int y = (int) (h / 2.0 - miraY() * (h / 2.0));
                desenharMira(matrices, x, y, true);
                return;
            }
            for (int i = 0; i < 2; i++) {
                int x = (int) (w / 2.0 + hx[i] * (w / 2.0));
                int y = (int) (h / 2.0 - hy[i] * (h / 2.0));
                desenharMira(matrices, x, y, i == maoAtiva);
            }
        });

        // dentro do inventário / crafting a mão vira o cursor
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) ->
                ScreenEvents.afterRender(screen).register((s, matrices, mouseX, mouseY, delta) -> {
                    if (ativo) desenharMaoCursor(matrices, mouseX, mouseY);
                }));
    }

    // ---------------------------------------------------------------- inventário na mão esquerda
    private static boolean painel = false;   // painel aberto (hotbar presa na mão esquerda)
    private static int painelMaoAnt = 1;     // mão ativa antes de abrir (volta no fim)
    private static int hoverSlot = -1;       // slot que a mão direita está apontando
    private static final float VEL_CAM = 3.0f; // graus por tick da câmera no numpad

    private static int cl(int v, int a, int b) { return Math.max(a, Math.min(v, b)); }

    private static void desenharLinha(MatrixStack m, int x1, int y1, int x2, int y2, int cor) {
        int n = Math.max(1, (int) (Math.hypot(x2 - x1, y2 - y1) / 2));
        for (int i = 0; i <= n; i++) {
            int x = x1 + (x2 - x1) * i / n;
            int y = y1 + (y2 - y1) * i / n;
            DrawableHelper.fill(m, x, y, x + 2, y + 2, cor);
        }
    }

    /** Hotbar presa na mão ESQUERDA; a mão DIREITA aponta o slot e uma linha mostra qual é. */
    private static void desenharPainel(MatrixStack m, MinecraftClient mc, int w, int h) {
        int pw = 9 * 20 + 4, ph = 28;
        int lx = (int) (w / 2.0 + hx[0] * (w / 2.0));
        int ly = (int) (h / 2.0 - hy[0] * (h / 2.0));
        int x0 = cl(lx - pw / 2, 2, w - pw - 2);
        int y0 = cl(ly - ph - 14, 2, h - ph - 2);
        int rx = (int) (w / 2.0 + hx[1] * (w / 2.0));
        int ry = (int) (h / 2.0 - hy[1] * (h / 2.0));

        DrawableHelper.fill(m, x0, y0, x0 + pw, y0 + ph, 0xAA000000);
        hoverSlot = -1;
        int selecionado = mc.player.getInventory().selectedSlot;
        int cx = 0, cy = 0;
        for (int i = 0; i < 9; i++) {
            int sx = x0 + 3 + i * 20;
            int sy = y0 + 5;
            boolean sobre = rx >= sx - 1 && rx < sx + 19 && ry >= sy - 2 && ry < sy + 20;
            if (sobre) { hoverSlot = i; cx = sx + 9; cy = sy + 9; }
            int borda = sobre ? 0xFFFFFFFF : (i == selecionado ? 0xFFFFD84D : 0xFF555555);
            DrawableHelper.fill(m, sx - 1, sy - 1, sx + 19, sy + 19, borda);
            DrawableHelper.fill(m, sx, sy, sx + 18, sy + 18, 0xFF2B2B2B);
            ItemStack st = mc.player.getInventory().getStack(i);
            if (!st.isEmpty()) {
                mc.getItemRenderer().renderGuiItemIcon(m, st, sx + 1, sy + 1);
                mc.getItemRenderer().renderGuiItemOverlay(m, mc.textRenderer, st, sx + 1, sy + 1);
            }
        }
        if (hoverSlot >= 0) {
            desenharLinha(m, rx, ry, cx, cy, 0xFFFFFFFF); // linha da mão direita até o slot
            ItemStack st = mc.player.getInventory().getStack(hoverSlot);
            if (!st.isEmpty()) {
                mc.textRenderer.drawWithShadow(m, st.getName(), x0 + 2, y0 - 10, 0xFFFFFF);
            }
        }
    }

    // ---------------------------------------------------------------- mouse -> mão
    private static final double SENS_MOUSE = 0.0035;

    /** true enquanto o modo está ligado e a tecla de segurar (X) está apertada. */
    public static boolean segurando() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return ativo && teclaX != null && teclaX.isPressed() && mc.currentScreen == null;
    }

    /** Chamado pelo EntityMixin: com X segurado o mouse move a mão em vez de girar a câmera. */
    public static void moverMao(double dx, double dy) {
        mover(dx * SENS_MOUSE, -dy * SENS_MOUSE);
    }

    /** Move a mão ativa (ou as duas juntas, no modo G) em coordenadas de tela (-1..1). */
    private static void mover(double ddx, double ddy) {
        if (juntas) {
            double cx = MathHelper.clamp((hx[0] + hx[1]) / 2 + ddx, -0.95 + ESPACO, 0.95 - ESPACO);
            double cy = MathHelper.clamp((hy[0] + hy[1]) / 2 + ddy, -0.95, 0.95);
            hx[0] = cx - ESPACO;
            hx[1] = cx + ESPACO;
            hy[0] = cy;
            hy[1] = cy;
        } else {
            hx[maoAtiva] = MathHelper.clamp(hx[maoAtiva] + ddx, -0.95, 0.95);
            hy[maoAtiva] = MathHelper.clamp(hy[maoAtiva] + ddy, -0.95, 0.95);
        }
    }

    /** Ponto de mira: a mão ativa, ou o meio das duas mãos no modo juntas. */
    public static double miraX() { return juntas ? (hx[0] + hx[1]) / 2 : hx[maoAtiva]; }
    public static double miraY() { return juntas ? (hy[0] + hy[1]) / 2 : hy[maoAtiva]; }

    // ---------------------------------------------------------------- tick
    private void tick(MinecraftClient mc) {
        while (teclaH.wasPressed()) {
            ativo = !ativo;
            if (!ativo) { juntas = false; painel = false; } // desligou: sai do modo juntas e fecha o painel
            if (mc.player != null) {
                mc.player.sendMessage(Text.literal(ativo ? "Modo mãos: LIGADO" : "Modo mãos: DESLIGADO (jogando normal)"), true);
            }
        }
        if (painel && (!ativo || mc.currentScreen != null)) { painel = false; maoAtiva = painelMaoAnt; }
        while (teclaV.wasPressed()) {
            if (!ativo) {
                if (mc.player != null) mc.player.sendMessage(Text.literal("Ligue o modo mãos com H primeiro"), true);
                continue;
            }
            if (mc.currentScreen != null || mc.player == null) continue;
            if (juntas) {
                mc.player.sendMessage(Text.literal("Desligue o modo 2 mãos juntas (G) pra usar o inventário"), true);
                continue;
            }
            if (!painel) {
                painel = true;
                painelMaoAnt = maoAtiva;
                maoAtiva = 1; // a mão direita é a que aponta
                mc.player.sendMessage(Text.literal("Inventário na mão esquerda: aponte com a direita e aperte V pra escolher"), true);
            } else {
                if (hoverSlot >= 0) mc.player.getInventory().selectedSlot = hoverSlot;
                painel = false;
                maoAtiva = painelMaoAnt;
            }
        }
        while (teclaG.wasPressed()) {
            if (!ativo) {
                if (mc.player != null) mc.player.sendMessage(Text.literal("Ligue o modo mãos com H primeiro"), true);
                continue;
            }
            if (painel) continue; // com o inventário aberto não dá pra juntar as mãos
            juntas = !juntas;
            if (juntas) {
                // junta as duas mãos no meio, lado a lado
                double cx = MathHelper.clamp((hx[0] + hx[1]) / 2, -0.95 + ESPACO, 0.95 - ESPACO);
                double cy = MathHelper.clamp((hy[0] + hy[1]) / 2, -0.95, 0.95);
                hx[0] = cx - ESPACO; hx[1] = cx + ESPACO; hy[0] = cy; hy[1] = cy;
            }
            if (mc.player != null) {
                mc.player.sendMessage(Text.literal(juntas ? "2 mãos juntas: LIGADO (mira no meio)" : "2 mãos juntas: DESLIGADO"), true);
            }
        }
        while (teclaZ.wasPressed()) {
            if (ativo && !painel) {
                maoAtiva = 1 - maoAtiva;
                if (mc.player != null) {
                    mc.player.sendMessage(Text.literal(maoAtiva == 0 ? "Mão esquerda" : "Mão direita"), true);
                }
            }
        }

        enviarEstado(mc);
        MaosVrEscalada.tick(mc);

        // esconde a mão normal do jogo só enquanto o modo está ligado
        mc.gameRenderer.setRenderHand(!ativo);

        if (!ativo) return;

        // trava na 1ª pessoa (sem F5 / 2ª / 3ª pessoa)
        if (mc.options.getPerspective() != Perspective.FIRST_PERSON) {
            mc.options.setPerspective(Perspective.FIRST_PERSON);
        }

        // ajuste fino do item
        boolean mudou = false;
        if (itemXm.isPressed()) { itemX -= PASSO_ITEM; mudou = true; }
        if (itemXp.isPressed()) { itemX += PASSO_ITEM; mudou = true; }
        if (itemYp.isPressed()) { itemY += PASSO_ITEM; mudou = true; }
        if (itemYm.isPressed()) { itemY -= PASSO_ITEM; mudou = true; }
        if (itemZm.isPressed()) { itemZ -= PASSO_ITEM; mudou = true; }
        if (itemZp.isPressed()) { itemZ += PASSO_ITEM; mudou = true; }
        if (mudou && mc.player != null) {
            mc.player.sendMessage(Text.literal(String.format(java.util.Locale.ROOT,
                    "Item: x=%.3f y=%.3f z=%.3f", itemX, itemY, itemZ)), true);
        }

        // câmera pelo numpad (4/6 giram, 8/2 olham cima/baixo), junto com o mouse
        if (mc.currentScreen == null && mc.player != null) {
            float gy = (camDir.isPressed() ? 1 : 0) - (camEsq.isPressed() ? 1 : 0);
            float gp = (camBaixo.isPressed() ? 1 : 0) - (camCima.isPressed() ? 1 : 0);
            if (gy != 0 || gp != 0) {
                mc.player.setYaw(mc.player.getYaw() + gy * VEL_CAM);
                mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + gp * VEL_CAM, -90f, 90f));
            }
        }

        long janela = mc.getWindow().getHandle();
        boolean cima = InputUtil.isKeyPressed(janela, GLFW.GLFW_KEY_UP);
        boolean baixo = InputUtil.isKeyPressed(janela, GLFW.GLFW_KEY_DOWN);
        boolean esq = InputUtil.isKeyPressed(janela, GLFW.GLFW_KEY_LEFT);
        boolean dir = InputUtil.isKeyPressed(janela, GLFW.GLFW_KEY_RIGHT);

        if (mc.currentScreen == null) {
            // no jogo: setas também movem a mão ativa
            mover(((dir ? 1 : 0) - (esq ? 1 : 0)) * VEL_SETAS,
                  ((cima ? 1 : 0) - (baixo ? 1 : 0)) * VEL_SETAS);
        } else {
            // em menus: setas movem o cursor (a mão)
            double passo = 12;
            double dx = (dir ? passo : 0) - (esq ? passo : 0);
            double dy = (baixo ? passo : 0) - (cima ? passo : 0);
            if (dx != 0 || dy != 0) {
                GLFW.glfwSetCursorPos(janela, mc.mouse.getX() + dx, mc.mouse.getY() + dy);
            }
        }
    }

    // ---------------------------------------------------------------- mira / raio
    /** Direção (no mundo) para onde a mão ativa está apontando. */
    public static Vec3d direcaoDaMao(MinecraftClient mc, float td) {
        double nx = miraX();
        double ny = miraY();

        double fovV = Math.toRadians(mc.options.getFov().getValue());
        double aspecto = (double) mc.getWindow().getFramebufferWidth() / mc.getWindow().getFramebufferHeight();
        double tv = Math.tan(fovV / 2.0);

        float pitch = mc.player.getPitch(td);
        float yaw = mc.player.getYaw(td);
        Vec3d frente = Vec3d.fromPolar(pitch, yaw);
        Vec3d cima = Vec3d.fromPolar(pitch - 90f, yaw);
        Vec3d direita = frente.crossProduct(cima).normalize(); // frente x cima = direita do jogador

        return frente
                .add(direita.multiply(nx * tv * aspecto))
                .add(cima.multiply(ny * tv))
                .normalize();
    }

    /** Vira o jogador (cliente + servidor) pra mira da mão. Usado pra projéteis saírem de onde a mão aponta. */
    public static float[] apontar(MinecraftClient mc) {
        if (!ativo || mc.player == null || mc.currentScreen != null || mc.getNetworkHandler() == null) return null;
        Vec3d d = direcaoDaMao(mc, 1.0f);
        float yaw = (float) Math.toDegrees(Math.atan2(-d.x, d.z));
        float pitch = (float) -Math.toDegrees(Math.asin(MathHelper.clamp(d.y, -1, 1)));
        float[] orig = {mc.player.getYaw(), mc.player.getPitch()};
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, mc.player.isOnGround()));
        return orig;
    }

    public static void restaurar(MinecraftClient mc, float[] orig) {
        if (orig == null || mc.player == null || mc.getNetworkHandler() == null) return;
        mc.player.setYaw(orig[0]);
        mc.player.setPitch(orig[1]);
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(orig[0], orig[1], mc.player.isOnGround()));
    }

    /** Lança um raio da câmera passando pela posição da mão e troca o alvo do jogo por ele.
     *  Chamado pelo GameRendererMixin logo depois do jogo calcular a mira normal. */
    public static void aplicarMira(MinecraftClient mc, float td) {
        if (!ativo || mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (mc.interactionManager == null) return;

        if (painel) { // escolhendo item: não deixa a mão quebrar/usar nada
            mc.crosshairTarget = BlockHitResult.createMissed(mc.player.getCameraPosVec(td), Direction.UP, mc.player.getBlockPos());
            mc.targetedEntity = null;
            return;
        }

        Vec3d dir = direcaoDaMao(mc, td);

        double alcance = mc.interactionManager.getReachDistance();
        Vec3d origem = mc.player.getCameraPosVec(td);
        Vec3d fim = origem.add(dir.multiply(alcance));

        BlockHitResult hit = mc.world.raycast(new RaycastContext(
                origem, fim, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, mc.player));
        HitResult alvo;
        if (hit.getType() == HitResult.Type.BLOCK) {
            alvo = hit;
        } else {
            alvo = BlockHitResult.createMissed(fim, hit.getSide(), hit.getBlockPos());
        }

        // mobs / jogadores: o alcance de bater é menor que o de quebrar bloco
        double alcanceEntidade = mc.interactionManager.hasExtendedReach() ? 6.0 : 3.0;
        Vec3d fimEntidade = origem.add(dir.multiply(alcanceEntidade));
        Box caixa = mc.player.getBoundingBox().stretch(dir.multiply(alcanceEntidade)).expand(1.0, 1.0, 1.0);
        EntityHitResult ent = ProjectileUtil.raycast(mc.player, origem, fimEntidade, caixa,
                e -> !e.isSpectator() && e.canHit(), alcanceEntidade * alcanceEntidade);
        if (ent != null) {
            double distBloco = alvo.getType() == HitResult.Type.BLOCK
                    ? alvo.getPos().squaredDistanceTo(origem) : Double.MAX_VALUE;
            if (origem.squaredDistanceTo(ent.getPos()) < distBloco) {
                alvo = ent;
            }
        }
        mc.crosshairTarget = alvo;
        mc.targetedEntity = (alvo instanceof EntityHitResult eh) ? eh.getEntity() : null;
    }

    // ---------------------------------------------------------------- multiplayer
    private static class Remoto {
        boolean ativo, novo = true;
        int ativa = 1;
        long ultimo;
        double[] tx = new double[2], ty = new double[2], cx = new double[2], cy = new double[2];
    }

    private static final Map<UUID, Remoto> remotos = new ConcurrentHashMap<>();
    private int contadorEnvio = 0;
    private boolean enviouAtivo = false;

    /** Manda a posição das suas mãos pro servidor (que repassa pros outros jogadores). */
    private void enviarEstado(MinecraftClient mc) {
        if (mc.player == null || mc.getNetworkHandler() == null) return;
        if (!ClientPlayNetworking.canSend(MaosVrNet.CANAL)) return; // servidor sem o mod: ignora
        boolean precisa;
        if (ativo) {
            contadorEnvio++;
            precisa = contadorEnvio >= 3; // ~7 vezes por segundo
        } else {
            precisa = enviouAtivo; // manda uma vez avisando que desligou
        }
        if (!precisa) return;
        contadorEnvio = 0;
        enviouAtivo = ativo;
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeBoolean(ativo);
        buf.writeByte(maoAtiva);
        buf.writeFloat((float) hx[0]);
        buf.writeFloat((float) hy[0]);
        buf.writeFloat((float) hx[1]);
        buf.writeFloat((float) hy[1]);
        ClientPlayNetworking.send(MaosVrNet.CANAL, buf);
    }

    /** Desenha as mãos dos outros jogadores que também têm o mod. */
    private void desenharRemotas(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || remotos.isEmpty()) return;

        long agora = System.currentTimeMillis();
        VertexConsumerProvider.Immediate vcp = mc.getBufferBuilders().getEntityVertexConsumers();
        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickDelta();
        boolean desenhou = false;

        for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            Remoto r = remotos.get(p.getUuid());
            if (r == null || !r.ativo || agora - r.ultimo > 3000) continue;
            if (p.squaredDistanceTo(mc.player) > 48 * 48) continue;
            Object rr = mc.getEntityRenderDispatcher().getRenderer(p);
            if (!(rr instanceof PlayerEntityRenderer renderer)) continue;

            for (int k = 0; k < 2; k++) {
                r.cx[k] += (r.tx[k] - r.cx[k]) * 0.35;
                r.cy[k] += (r.ty[k] - r.cy[k]) * 0.35;
            }

            Vec3d olho = p.getCameraPosVec(td);
            MatrixStack ms = ctx.matrixStack();
            ms.push();
            ms.translate(olho.x - cam.x, olho.y - cam.y, olho.z - cam.z);
            // do espaço da câmera dele para o mundo
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-(p.getYaw(td) + 180f)));
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-p.getPitch(td)));
            int luz = renderer.getLight(p, td);
            for (int k = 0; k < 2; k++) {
                ItemStack item = (k == r.ativa) ? p.getMainHandStack() : p.getOffHandStack();
                desenharUmaMao(ms, vcp, renderer, p, k, r.cx[k], r.cy[k], TV_PADRAO, 16.0 / 9.0, luz, item, mc);
            }
            ms.pop();
            desenhou = true;
        }
        if (desenhou) vcp.draw();
    }

    // ---------------------------------------------------------------- mãos 3D
    private static final double TV_PADRAO = Math.tan(Math.toRadians(35));

    private void desenharMaos3D() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!ativo || mc.player == null || mc.currentScreen != null || mc.options.hudHidden) return;

        Object r = mc.getEntityRenderDispatcher().getRenderer(mc.player);
        if (!(r instanceof PlayerEntityRenderer renderer)) return;

        double fovV = Math.toRadians(mc.options.getFov().getValue());
        double aspecto = (double) mc.getWindow().getFramebufferWidth() / mc.getWindow().getFramebufferHeight();
        double tv = Math.tan(fovV / 2.0);

        VertexConsumerProvider.Immediate vcp = mc.getBufferBuilders().getEntityVertexConsumers();

        // mãos sempre por cima do mundo
        RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, MinecraftClient.IS_SYSTEM_MAC);

        for (int i = 0; i < 2; i++) {
            // mão ativa = item da mão principal, outra = mão secundária
            ItemStack item = (i == maoAtiva) ? mc.player.getMainHandStack() : mc.player.getOffHandStack();
            desenharUmaMao(new MatrixStack(), vcp, renderer, mc.player, i, hx[i], hy[i], tv, aspecto,
                    LightmapTextureManager.MAX_LIGHT_COORDINATE, item, mc);
        }
        vcp.draw();
    }

    /** Desenha um braço + item. A origem do MatrixStack é o olho do jogador (espaço da câmera dele). */
    private static void desenharUmaMao(MatrixStack ms, VertexConsumerProvider vcp, PlayerEntityRenderer renderer,
                                       AbstractClientPlayerEntity p, int i, double mx, double my,
                                       double tv, double aspecto, int luz, ItemStack item, MinecraftClient mc) {
        boolean direita = (i == 1);

        // ponto que a mão aponta (1 bloco à frente da câmera, no espaço da tela)
        double px = mx * tv * aspecto;
        double py = my * tv;
        double pz = -1.0;

        // base do braço (saindo de baixo da tela)
        double bx = direita ? 0.30 : -0.30;
        double by = -0.40;
        double bz = -0.35;

        double dx = px - bx;
        double dy = py - by;
        double dz = pz - bz;
        double comp = Math.sqrt(dx * dx + dy * dy + dz * dz);
        float yaw = (float) Math.toDegrees(-Math.atan2(dx, -dz));
        float pitch = (float) Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        float escala = MathHelper.clamp((float) (comp / 0.75), 0.8f, 1.8f); // braço = 0,75 bloco

        ms.push();
        ms.translate(bx, by, bz);
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));

        // braço com a skin do jogador
        ms.push();
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90f)); // braço aponta pra frente
        ms.scale(1f, escala, 1f);
        ms.translate(direita ? 0.375 : -0.375, 0, 0); // centraliza o braço no eixo
        if (direita) {
            renderer.renderRightArm(ms, vcp, luz, p);
        } else {
            renderer.renderLeftArm(ms, vcp, luz, p);
        }
        ms.pop();

        // item na ponta da mão, com o modelo de "segurando na mão" do jogo (espada em pé, picareta,
        // machado, tridente...) e não o ícone chato. A gente desfaz o deslocamento que o jogo aplica
        // nesse modelo pra ele ficar centrado, e nas ferramentas deixa o CABO (não o meio) na mão.
        if (!item.isEmpty() && mc.world != null) {
            boolean canhoto = !direita;
            ModelTransformationMode modo = direita
                    ? ModelTransformationMode.FIRST_PERSON_RIGHT_HAND
                    : ModelTransformationMode.FIRST_PERSON_LEFT_HAND;
            BakedModel modelo = mc.getItemRenderer().getModel(item, mc.world, p, p.getId() + i);
            Transformation t = modelo.getTransformation().getTransformation(modo);

            // ponto do item que tem que ficar na mão (relativo ao centro do item): o cabo nas ferramentas
            boolean cabo = item.getItem() instanceof ToolItem || item.getItem() instanceof FishingRodItem;
            Vector3f off = new Vector3f(cabo ? -0.31f : 0f, cabo ? -0.31f : 0f, 0f);
            float sinal = canhoto ? -1f : 1f; // mão esquerda espelha rotação Y/Z e translação X
            Quaternionf rot = new Quaternionf().rotationXYZ(
                    (float) Math.toRadians(t.rotation.x()),
                    (float) Math.toRadians(t.rotation.y() * sinal),
                    (float) Math.toRadians(t.rotation.z() * sinal));
            off.mul(t.scale.x(), t.scale.y(), t.scale.z());
            rot.transform(off);
            off.add(t.translation.x() * sinal, t.translation.y(), t.translation.z());

            ms.push();
            ms.translate(itemX, itemY, -escala * 0.75 + itemZ);
            ms.scale(1.4f, 1.4f, 1.4f);
            ms.translate(-off.x(), -off.y(), -off.z());
            mc.getItemRenderer().renderItem(p, item, modo, canhoto, ms, vcp, mc.world,
                    luz, OverlayTexture.DEFAULT_UV, p.getId() + i);
            ms.pop();
        }
        ms.pop();
    }

    // ---------------------------------------------------------------- HUD
    private static void desenharMira(MatrixStack m, int x, int y, boolean ativa) {
        int cor = ativa ? 0xFFFFFFFF : 0x66FFFFFF;
        int sombra = ativa ? 0xAA000000 : 0x33000000;
        int t = ativa ? 5 : 2;
        // sombra
        DrawableHelper.fill(m, x - t - 1, y - 1, x + t + 2, y + 2, sombra);
        DrawableHelper.fill(m, x - 1, y - t - 1, x + 2, y + t + 2, sombra);
        // cruz
        DrawableHelper.fill(m, x - t, y, x + t + 1, y + 1, cor);
        DrawableHelper.fill(m, x, y - t, x + 1, y + t + 1, cor);
    }

    /** Mãozinha simples usada como cursor em inventários. */
    private static void desenharMaoCursor(MatrixStack m, int x, int y) {
        int pele = 0xFFF1C27D;
        int sombra = 0xFF8D5524;
        DrawableHelper.fill(m, x - 1, y - 1, x + 13, y + 14, 0xFFFFFFFF);
        DrawableHelper.fill(m, x, y, x + 12, y + 13, pele);
        for (int i = 0; i < 4; i++) {
            DrawableHelper.fill(m, x + i * 3, y - 5, x + i * 3 + 2, y, pele);
        }
        DrawableHelper.fill(m, x, y + 11, x + 12, y + 13, sombra);
    }
}
