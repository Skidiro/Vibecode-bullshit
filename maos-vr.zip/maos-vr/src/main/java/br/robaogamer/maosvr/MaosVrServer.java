package br.robaogamer.maosvr;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Lado do servidor: recebe a posição das mãos de um jogador e repassa pros outros jogadores
 * que estão perto. Só funciona se o mod estiver instalado no servidor (ou no mundo LAN do anfitrião).
 */
public class MaosVrServer implements ModInitializer {
    private static final double TP_MAX = 26.0;                       // distância máxima de um TP
    private static final Map<UUID, Integer> ultimoTp = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        MaosVrItens.registrar();

        // TP do modo mãos: o servidor confere tudo antes de teleportar
        ServerPlayNetworking.registerGlobalReceiver(MaosVrNet.TP, (server, player, handler, buf, sender) -> {
            double x = buf.readDouble(), y = buf.readDouble(), z = buf.readDouble();
            server.execute(() -> {
                if (player.isSpectator() || player.isDead()) return;
                int agora = server.getTicks();
                Integer ult = ultimoTp.get(player.getUuid());
                if (ult != null && agora - ult < 5) return;           // no máximo 1 TP a cada 5 ticks
                if (player.squaredDistanceTo(x, y, z) > TP_MAX * TP_MAX) return;
                ServerWorld w = (ServerWorld) player.world;
                BlockPos pe = new BlockPos((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
                if (!w.getWorldBorder().contains(pe) || !w.isChunkLoaded(pe)) return;
                BlockPos acima = pe.up();
                if (!w.getBlockState(pe).getCollisionShape(w, pe).isEmpty()) return;       // precisa caber em pé
                if (!w.getBlockState(acima).getCollisionShape(w, acima).isEmpty()) return;
                ultimoTp.put(player.getUuid(), agora);
                player.teleport(w, x, y, z, player.getYaw(), player.getPitch());
                player.fallDistance = 0;
                w.playSound(null, x, y, z, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.6f, 1.0f);
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(MaosVrNet.CANAL, (server, player, handler, buf, sender) -> {
            boolean ativo = buf.readBoolean();
            int ativa = buf.readByte();
            float a = buf.readFloat(), b = buf.readFloat(), c = buf.readFloat(), d = buf.readFloat();
            boolean painel = buf.readBoolean();          // inventário aberto na mão esquerda?
            int hover = buf.readByte();                   // slot que a mão direita está apontando (-1 = nenhum)
            boolean comItens = buf.readBoolean();         // veio a lista de itens junto?
            final int[] ids = new int[36];
            final byte[] qt = new byte[36];
            if (comItens) {
                for (int i = 0; i < 36; i++) { ids[i] = buf.readVarInt(); qt[i] = buf.readByte(); }
            }

            server.execute(() -> {
                for (ServerPlayerEntity outro : server.getPlayerManager().getPlayerList()) {
                    if (outro == player) continue;
                    if (outro.world != player.world) continue;
                    if (outro.squaredDistanceTo(player) > 128 * 128) continue;
                    if (!ServerPlayNetworking.canSend(outro, MaosVrNet.CANAL)) continue;

                    PacketByteBuf out = PacketByteBufs.create();
                    out.writeUuid(player.getUuid());
                    out.writeBoolean(ativo);
                    out.writeByte(ativa);
                    out.writeFloat(a);
                    out.writeFloat(b);
                    out.writeFloat(c);
                    out.writeFloat(d);
                    out.writeBoolean(painel);
                    out.writeByte(hover);
                    out.writeBoolean(comItens);
                    if (comItens) {
                        for (int i = 0; i < 36; i++) { out.writeVarInt(ids[i]); out.writeByte(qt[i]); }
                    }
                    ServerPlayNetworking.send(outro, MaosVrNet.CANAL, out);
                }
            });
        });
    }
}
