package com.vrhands;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class VrHandsItems {
    public static final Item CLIMBING_CLAW = new Item(new Item.Settings().maxCount(1));

    public static void register() {
        Registry.register(Registries.ITEM, new Identifier("vrhands", "climbing_claw"), CLIMBING_CLAW);
    }
}
