package com.vrhands;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Matrix4f;
import net.minecraft.util.math.Vec3d;

public class HandRenderer {
    private static final float HALF = 0.14f;

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!HandState.enabled || mc.player == null) return;
        if (mc.options.getPerspective() != Perspective.FIRST_PERSON) return;

        // maos: azul = esquerda, laranja = direita, verde = ancorada na escalada
        float[] l = {0.2f, 0.7f, 1.0f};
        float[] r = {1.0f, 0.55f, 0.1f};
        if (HandState.climbing) {
            if (HandState.anchoredL) l = new float[]{0.2f, 1.0f, 0.2f};
            if (HandState.anchoredR) r = new float[]{0.2f, 1.0f, 0.2f};
        }
        drawHand(ctx, HandState.left, l[0], l[1], l[2]);
        drawHand(ctx, HandState.right, r[0], r[1], r[2]);

        // miras independentes (cruz no bloco mirado)
        if (HandState.leftMira && HandState.leftTarget != null
                && HandState.leftTarget.getType() == HitResult.Type.BLOCK) {
            drawCross(ctx, HandState.leftTarget.getPos(), 0.2f, 0.7f, 1.0f);
        }
        if (HandState.rightMira && HandState.rightTarget != null
                && HandState.rightTarget.getType() == HitResult.Type.BLOCK) {
            drawCross(ctx, HandState.rightTarget.getPos(), 1.0f, 0.55f, 0.1f);
        }

        // teleporte
        if (HandState.tpSelecting && HandState.tpTarget != null) drawTeleport(ctx);
    }

    private static float[] avgOff() {
        return new float[]{
                (HandState.left[0] + HandState.right[0]) / 2f,
                (HandState.left[1] + HandState.right[1]) / 2f,
                (HandState.left[2] + HandState.right[2]) / 2f};
    }

    private static void drawTeleport(WorldRenderContext ctx) {
        Vec3d camPos = ctx.camera().getPos();
        Vec3d from = HandPhysics.center(camPos, ctx.camera().getYaw(), ctx.camera().getPitch(), avgOff());
        Vec3d to = HandState.tpTarget;
        Vec3d mid = from.add(to).multiply(0.5).add(0, 2.0, 0);
        for (int i = 0; i < 24; i++) {
            double t0 = i / 24.0, t1 = (i + 1) / 24.0;
            drawLine(ctx, bezier(from, mid, to, t0), bezier(from, mid, to, t1), 1f, 1f, 0.2f);
        }
        Vec3d feet = to.subtract(0, 1, 0);
        drawBoxAt(ctx, feet, 0.3f, 1f, 1f, 0.2f);
        drawLine(ctx, feet, to.add(0, 1, 0), 1f, 1f, 0.2f);
    }

    private static Vec3d bezier(Vec3d a, Vec3d c, Vec3d b, double t) {
        double u = 1 - t;
        return a.multiply(u * u).add(c.multiply(2 * u * t)).add(b.multiply(t * t));
    }

    private static void drawHand(WorldRenderContext ctx, float[] o, float r, float g, float b) {
        Vec3d camPos = ctx.camera().getPos();
        Vec3d center = HandPhysics.center(camPos, ctx.camera().getYaw(), ctx.camera().getPitch(), o);
        MatrixStack matrices = ctx.matrixStack();
        matrices.push();
        matrices.translate(center.x - camPos.x, center.y - camPos.y, center.z - camPos.z);
        VertexConsumerProvider.Immediate vcp = MinecraftClient.getInstance()
                .getBufferBuilders().getEntityVertexConsumers();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLines());
        drawBox(vc, matrices, HALF, r, g, b);
        vcp.draw();
        matrices.pop();
    }

    private static void drawBoxAt(WorldRenderContext ctx, Vec3d pos, float half, float r, float g, float b) {
        Vec3d camPos = ctx.camera().getPos();
        MatrixStack matrices = ctx.matrixStack();
        matrices.push();
        matrices.translate(pos.x - camPos.x, pos.y - camPos.y, pos.z - camPos.z);
        VertexConsumerProvider.Immediate vcp = MinecraftClient.getInstance()
                .getBufferBuilders().getEntityVertexConsumers();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLines());
        drawBox(vc, matrices, half, r, g, b);
        vcp.draw();
        matrices.pop();
    }

    private static void drawCross(WorldRenderContext ctx, Vec3d pos, float r, float g, float b) {
        float s = 0.06f;
        drawLine(ctx, pos.add(-s, 0, 0), pos.add(s, 0, 0), r, g, b);
        drawLine(ctx, pos.add(0, -s, 0), pos.add(0, s, 0), r, g, b);
        drawLine(ctx, pos.add(0, 0, -s), pos.add(0, 0, s), r, g, b);
    }

    private static void drawLine(WorldRenderContext ctx, Vec3d a, Vec3d b, float r, float g, float bl) {
        Vec3d camPos = ctx.camera().getPos();
        MatrixStack matrices = ctx.matrixStack();
        matrices.push();
        matrices.translate(a.x - camPos.x, a.y - camPos.y, a.z - camPos.z);
        VertexConsumerProvider.Immediate vcp = MinecraftClient.getInstance()
                .getBufferBuilders().getEntityVertexConsumers();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLines());
        Matrix4f m = matrices.peek().getPositionMatrix();
        int R = (int) (r * 255), G = (int) (g * 255), B = (int) (bl * 255);
        vc.vertex(m, 0, 0, 0).color(R, G, B, 255).next();
        vc.vertex(m, (float) (b.x - a.x), (float) (b.y - a.y), (float) (b.z - a.z)).color(R, G, B, 255).next();
        vcp.draw();
        matrices.pop();
    }

    private static void drawBox(VertexConsumer vc, MatrixStack matrices, float h, float r, float g, float b) {
        Matrix4f m = matrices.peek().getPositionMatrix();
        int R = (int) (r * 255), G = (int) (g * 255), B = (int) (b * 255);
        edge(vc, m, -h,-h,-h,  h,-h,-h, R,G,B); edge(vc, m, -h, h,-h,  h, h,-h, R,G,B);
        edge(vc, m, -h,-h, h,  h,-h, h, R,G,B); edge(vc, m, -h, h, h,  h, h, h, R,G,B);
        edge(vc, m, -h,-h,-h, -h, h,-h, R,G,B); edge(vc, m,  h,-h,-h,  h, h,-h, R,G,B);
        edge(vc, m, -h,-h, h, -h, h, h, R,G,B); edge(vc, m,  h,-h, h,  h, h, h, R,G,B);
        edge(vc, m, -h,-h,-h, -h,-h, h, R,G,B); edge(vc, m,  h,-h,-h,  h,-h, h, R,G,B);
        edge(vc, m, -h, h,-h, -h, h, h, R,G,B); edge(vc, m,  h, h,-h,  h, h, h, R,G,B);
    }

    private static void edge(VertexConsumer vc, Matrix4f m,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             int R, int G, int B) {
        vc.vertex(m, x1, y1, z1).color(R, G, B, 255).next();
        vc.vertex(m, x2, y2, z2).color(R, G, B, 255).next();
    }
}
