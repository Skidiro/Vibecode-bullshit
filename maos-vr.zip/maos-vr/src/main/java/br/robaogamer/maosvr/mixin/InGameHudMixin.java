package br.robaogamer.maosvr.mixin;

import br.robaogamer.maosvr.MaosVrMod;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    // esconde a mira normal do centro: a mira agora fica em cima da mão
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void maosvr$esconderMira(MatrixStack matrices, CallbackInfo ci) {
        if (MaosVrMod.ativo) ci.cancel();
    }
}
