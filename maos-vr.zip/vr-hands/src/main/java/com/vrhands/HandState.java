package com.vrhands;

import net.minecraft.util.hit.BlockHitResult;

public class HandState {
    public static boolean enabled = false;      // H ligou/desligou
    public static boolean bothHands = false;    // X segurado: as duas maos seguem o mouse
    public static boolean singleHand = false;   // Z segurado: so a mao ativa segue o mouse
    public static int activeHand = 1;           // 1 = direita, 0 = esquerda

    public static float savedYaw = 0f, savedPitch = 0f;
    public static double lastX = 0, lastY = 0;

    // x = direita da camera, y = para cima, z = para frente (em blocos)
    public static final float[] left  = {-0.35f, -0.25f, 1.2f};
    public static final float[] right = { 0.35f, -0.25f, 1.2f};

    // ---- miras (1 por mao) ----
    public static BlockHitResult leftTarget, rightTarget;
    public static int leftTargetTicks, rightTargetTicks;
    public static boolean leftMira, rightMira;

    // ---- crawl estilo VR ----
    public static boolean crawlEnabled = false; // toggle do Y
    public static boolean crawling = false;     // engatado agora

    // ---- escalada ----
    public static boolean climbing = false;
    public static boolean anchoredL = false, anchoredR = false;

    // ---- teleporte ----
    public static boolean tpSelecting = false;
    public static net.minecraft.util.math.Vec3d tpTarget = null;

    public static float[] off(int hand) { return hand == 1 ? right : left; }

    public static void setTarget(int hand, BlockHitResult h) {
        if (h == null) return;
        if (hand == 1) { rightTarget = h; rightTargetTicks = 10; }
        else { leftTarget = h; leftTargetTicks = 10; }
    }

    public static BlockHitResult target(int hand) {
        if (hand == 1) return rightTargetTicks > 0 ? rightTarget : null;
        return leftTargetTicks > 0 ? leftTarget : null;
    }

    public static void decayTargets() {
        if (leftTargetTicks > 0) leftTargetTicks--;
        if (rightTargetTicks > 0) rightTargetTicks--;
    }

    public static void clamp() { clampHand(left); clampHand(right); }

    private static void clampHand(float[] o) {
        o[0] = Math.max(-3f, Math.min(3f, o[0]));
        o[1] = Math.max(-2f, Math.min(2f, o[1]));
        o[2] = Math.max(0.2f, Math.min(6f, o[2]));
    }
}
