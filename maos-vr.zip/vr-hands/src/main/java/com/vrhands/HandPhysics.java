package com.vrhands;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

// Fisica so entra em jogo quando necessario: as maos NAO atravessam blocos.
public class HandPhysics {
    // Posicao da mao no mundo, a partir de um ponto base (olho/camera),
    // yaw/pitch em GRAUS e offset {direita, cima, frente}.
    public static Vec3d center(Vec3d base, double yawDeg, double pitchDeg, float[] o) {
        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);
        double sy = Math.sin(yaw), cy = Math.cos(yaw);
        double sp = Math.sin(pitch), cp = Math.cos(pitch);
        Vec3d right = new Vec3d(-cy, 0, -sy);
        Vec3d forward = new Vec3d(-sy * cp, -sp, cy * cp);
        return base.add(right.multiply(o[0])).add(0, o[1], 0).add(forward.multiply(o[2]));
    }

    public static boolean solidAt(MinecraftClient mc, Vec3d pos) {
        if (mc.world == null) return false;
        BlockPos bp = BlockPos.ofFloored(pos);
        return mc.world.getBlockState(bp).isSolidBlock(mc.world, bp);
    }

    // Move a mao eixo por eixo, bloqueando os eixos que entrariam num bloco solido.
    public static void tryMove(MinecraftClient mc, float[] o, float dx, float dy, float dz) {
        if (mc.player == null || mc.world == null) {
            o[0] += dx; o[1] += dy; o[2] += dz;
            HandState.clamp();
            return;
        }
        Vec3d eye = mc.player.getEyePos();
        double yaw = mc.player.getYaw(), pitch = mc.player.getPitch();
        if (dx != 0f && !solidAt(mc, center(eye, yaw, pitch, new float[]{o[0] + dx, o[1], o[2]}))) o[0] += dx;
        if (dy != 0f && !solidAt(mc, center(eye, yaw, pitch, new float[]{o[0], o[1] + dy, o[2]}))) o[1] += dy;
        if (dz != 0f && !solidAt(mc, center(eye, yaw, pitch, new float[]{o[0], o[1], o[2] + dz}))) o[2] += dz;
        HandState.clamp();
    }

    // A mao esta "grudada" em algum bloco? (usado na escalada)
    public static boolean touchesSolid(MinecraftClient mc, float[] o) {
        if (mc.player == null || mc.world == null) return false;
        Vec3d c = center(mc.player.getEyePos(), mc.player.getYaw(), mc.player.getPitch(), o);
        double e = 0.18;
        return solidAt(mc, c)
                || solidAt(mc, c.add(e, 0, 0)) || solidAt(mc, c.add(-e, 0, 0))
                || solidAt(mc, c.add(0, e, 0)) || solidAt(mc, c.add(0, -e, 0))
                || solidAt(mc, c.add(0, 0, e)) || solidAt(mc, c.add(0, 0, -e));
    }
}
