package com.vrhands;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

// Estado de "crawl VR" por jogador (cliente manda, servidor aplica a pose).
public class CrawlState {
    private static final Map<UUID, Boolean> MAP = new ConcurrentHashMap<>();

    public static void set(UUID uuid, boolean v) {
        if (v) MAP.put(uuid, true);
        else MAP.remove(uuid);
    }

    public static boolean isCrawling(UUID uuid) {
        return MAP.containsKey(uuid);
    }

    public static void remove(UUID uuid) {
        MAP.remove(uuid);
    }
}
