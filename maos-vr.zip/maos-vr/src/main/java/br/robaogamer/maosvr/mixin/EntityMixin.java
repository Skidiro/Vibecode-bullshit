package br.robaogamer.maosvr.mixin;

import br.robaogamer.maosvr.MaosVrMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityMixin {
    // com o modo ligado, o mouse move a mão em vez de girar a câmera
    // (a câmera gira sozinha quando a mão chega perto da borda da tela)
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void maosvr$mouseMoveAMao(double dx, double dy, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (MaosVrMod.ativo && mc.player != null && mc.player == (Object) this && mc.currentScreen == null) {
            MaosVrMod.moverMao(dx, dy);
            ci.cancel();
        }
    }
}
