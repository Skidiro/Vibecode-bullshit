package com.vrhands;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.util.Identifier;

public class VrHandsServer implements ModInitializer {
    public static final Identifier CRAWL = new Identifier("vrhands", "crawl");
    public static final Identifier HELLO = new Identifier("vrhands", "hello");

    @Override
    public void onInitialize() {
        VrHandsItems.register();

        // avisa o cliente que o servidor tem o mod
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                ServerPlayNetworking.send(handler.getPlayer(), HELLO, PacketByteBufs.create()));

        // recebe o estado de crawl
        ServerPlayNetworking.registerGlobalReceiver(CRAWL, (server, player, handler, buf, sender) -> {
            boolean v = buf.readBoolean();
            server.execute(() -> CrawlState.set(player.getUuid(), v));
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
                CrawlState.remove(handler.player.getUuid()));
    }
}
