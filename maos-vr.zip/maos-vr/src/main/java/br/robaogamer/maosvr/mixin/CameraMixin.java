package br.robaogamer.maosvr.mixin;

import br.robaogamer.maosvr.MaosVrMod;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setPos(double x, double y, double z);
    @Shadow public abstract Vec3d getPos();
    @Shadow public abstract net.minecraft.entity.Entity getFocusedEntity();
    @Shadow public abstract boolean isThirdPerson();

    // inclinar o corpo: a câmera acompanha a cabeça
    @Inject(method = "update", at = @At("TAIL"), require = 0)
    private void maosvr$lean(CallbackInfo ci) {
        if (isThirdPerson()) return;
        Vec3d off = MaosVrMod.offsetCamera(getFocusedEntity(), MaosVrMod.tickDeltaAtual());
        if (off == null) return;
        Vec3d p = getPos();
        setPos(p.x + off.x, p.y + off.y, p.z + off.z);
    }
}
