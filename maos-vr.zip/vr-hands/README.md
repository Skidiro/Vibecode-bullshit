# VR Hands v1.1.0 (Fabric 1.20.1)

Mod que adiciona duas "maos" estilo VR no Minecraft, com mira propria por mao,
cliques funcionando, crawl de 1 bloco, teleporte com arco e item de escalada.

## Controles

### Base
- **H** — liga/desliga as maos (e trava o jogo em 1a pessoa)
- **Segurar X** — as DUAS maos seguem o mouse (modo VR)
- **Segurar Z** — so a mao ativa segue o mouse; apertar Z alterna esquerda/direita
- **Numpad 4 / 6** — girar a camera pros lados
- **Numpad 8 / 2** — olhar pra cima / baixo
- **Scroll do mouse** — aproxima / afasta as maos

### Miras e cliques
- Cada mao tem sua propria mira (cruz colorida no bloco mirado)
- **Modo X (duas maos):** LEFT click age na mao ESQUERDA, RIGHT click na DIREITA
- **Modo Z (uma mao):** a mao do mouse so move (sem mira) e os DOIS cliques
  vao pra mao das setas; a mira dela so aparece enquanto voce aperta seta
  (evita selecionar bloco errado). Trocar com Z inverte tudo.
- **Setas** — movem a segunda mao

### Crawl estilo VR (1 bloco de altura)
- **Y** — toggle da mecanica
- Agache (Shift) com o Y ativo: voce fica com 0.6 de altura e entra em
  buraco de 1 bloco
- Nesse modo o teclado NAO anda: voce se arrasta puxando com as DUAS maos
  (segure X e "alcance" as maos pra frente com o mouse, o corpo vai atras)

### Teleporte (estilo Minecraft VR)
- Só funciona com **X ativado** (modo das duas maos)
- **Segurar F** — mostra o arco e o marcador amarelo no destino
- **Soltar F** — teleporta

### Escalada
- Item: **Garra de Escalada** (`/give @s vrhands:climbing_claw`)
- Segure a garra em qualquer mao + **X ativado**: se a mao encostar num
  bloco, ela ancora (fica verde). Puxe o mouse pra BAIXO e voce SOBE,
  pro lado e voce se move na parede.

### Fisica das maos
- As maos NUNCA atravessam blocos (nem pelo mouse, nem pelo scroll,
  nem pelas setas). Fora isso elas nao tem fisica — so onde precisa
  (crawl e escalada).

## IMPORTANTE — Multiplayer
- O mod funciona em multiplayer, mas pra TUDO funcionar (crawl, item e
  registro do item) o **mod precisa estar instalado no servidor TAMBEM**
  (e nos jogadores).
- Mira, cliques, escalada e teleporte funcionam contra qualquer servidor
  (usam pacotes vanilla de interacao/movimento).
- O crawl detecta se o servidor tem o mod; sem ele, o crawl fica
  desativado sozinho pra nao causar dessincronia.

## Conflito de teclas
- **F** no vanilla = "trocar item com a mao secundaria". O mod drena os
  cliques pra nao spammar, mas o ideal e remapear essa tecla em
  Opcoes > Controles (procure "Swap Item With Offhand").

## Como gerar o .jar
1. Instale o **JDK 17** (Eclipse Temurin 17).
2. Baixe o template oficial: https://github.com/FabricMC/fabric-example-mod
   (Code > Download ZIP) e extraia.
3. Copie pra DENTRO da pasta: `build.gradle`, `settings.gradle`,
   `gradle.properties` e a pasta `src` deste mod (substituindo as do template).
4. No terminal da pasta:
   - Windows: `gradlew.bat build`
   - Linux/Mac: `./gradlew build`
5. O mod fica em `build/libs/vr-hands-1.1.0.jar` (o SEM "-sources").

## Como jogar
1. Instale o **Fabric Loader 1.20.1** (fabricmc.net/use/installer).
2. Baixe o **Fabric API 1.20.1** (modrinth.com/mod/fabric-api).
3. Coloque `vr-hands-1.1.0.jar` + Fabric API na pasta `.minecraft/mods`
   (e no servidor, se for jogar multiplayer).

## Conferencia do codigo (feita antes de entregar)
- Vetor "direita da camera" = (-cos(yaw), 0, -sin(yaw)) — conferido:
  virando a camera, a mao certa fica do lado certo (nao espelha).
- Mouse pra cima sobe a mao (GLFW dy negativo -> y aumenta).
- No modo Z a mira da mao do mouse fica DESLIGADA (movemento continua).
- Cliques vanilla sao suprimidos durante os modos de mao (mixin), entao
  nao da acao dupla com o crosshair central.
- A mira da mao das setas so atualiza com seta apertada, mas o alvo fica
  guardado por ~10 ticks pra o clique nao falhar.

## Ideias pra proximas versoes
- Ver as maos dos outros jogadores no multiplayer
- Modelo 3D de mao com dedos
- Sons de arraste na escalada
