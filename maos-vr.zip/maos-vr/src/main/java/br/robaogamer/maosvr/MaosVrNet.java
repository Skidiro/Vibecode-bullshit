package br.robaogamer.maosvr;

import net.minecraft.util.Identifier;

/** Canal de rede usado pra os jogadores verem as mãos uns dos outros. */
public class MaosVrNet {
    public static final Identifier CANAL = new Identifier("maosvr", "maos");
    /** Cliente -> servidor: "me teleporta pra essa posição" (TP do modo mãos). */
    public static final Identifier TP = new Identifier("maosvr", "tp");
}
