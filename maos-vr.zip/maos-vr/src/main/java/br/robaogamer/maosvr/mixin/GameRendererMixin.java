package br.robaogamer.maosvr.mixin;

import br.robaogamer.maosvr.MaosVrMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    // o jogo recalcula a mira do centro toda hora; logo depois disso trocamos pela mira da mão
    @Inject(method = "updateTargetedEntity", at = @At("RETURN"))
    private void maosvr$miraDaMao(float tickDelta, CallbackInfo ci) {
        MaosVrMod.aplicarMira(MinecraftClient.getInstance(), tickDelta);
    }
}
