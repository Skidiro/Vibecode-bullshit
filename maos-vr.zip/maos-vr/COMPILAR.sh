#!/bin/sh
# Linux/Mac: precisa de Java 17+
cd "$(dirname "$0")"
./gradlew build || { echo "Deu erro, manda print pro Claude."; exit 1; }
for f in build/libs/maos-vr-*.jar; do
  case "$f" in *sources*|*dev*) ;; *) cp "$f" maos-vr.jar ;; esac
done
echo "PRONTO: maos-vr.jar nesta pasta."
