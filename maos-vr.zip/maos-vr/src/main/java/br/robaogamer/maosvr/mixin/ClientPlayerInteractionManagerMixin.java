package br.robaogamer.maosvr.mixin;

import br.robaogamer.maosvr.MaosVrMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public class ClientPlayerInteractionManagerMixin {
    private float[] maosvr$orig;

    // usar item (bola de neve, pérola, besta, foguete...): vira o jogador pra mira da mão antes de usar
    @Inject(method = "interactItem", at = @At("HEAD"))
    private void maosvr$antesDeUsar(PlayerEntity player, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        maosvr$orig = MaosVrMod.apontar(MinecraftClient.getInstance());
    }

    @Inject(method = "interactItem", at = @At("RETURN"))
    private void maosvr$depoisDeUsar(PlayerEntity player, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        MaosVrMod.restaurar(MinecraftClient.getInstance(), maosvr$orig);
        maosvr$orig = null;
    }

    // soltar o arco / tridente: a direção do tiro é definida na hora de soltar
    @Inject(method = "stopUsingItem", at = @At("HEAD"))
    private void maosvr$antesDeSoltar(PlayerEntity player, CallbackInfo ci) {
        maosvr$orig = MaosVrMod.apontar(MinecraftClient.getInstance());
    }

    @Inject(method = "stopUsingItem", at = @At("RETURN"))
    private void maosvr$depoisDeSoltar(PlayerEntity player, CallbackInfo ci) {
        MaosVrMod.restaurar(MinecraftClient.getInstance(), maosvr$orig);
        maosvr$orig = null;
    }
}
