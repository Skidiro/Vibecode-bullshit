package br.robaogamer.maosvr;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Lado do servidor: recebe a posição das mãos de um jogador e repassa pros outros jogadores
 * que estão perto. Só funciona se o mod estiver instalado no servidor (ou no mundo LAN do anfitrião).
 */
public class MaosVrServer implements ModInitializer {
    private static final double TP_MAX = 26.0;                       // distância máxima de um TP
    private static final Map<UUID, Integer> ultimoTp = new ConcurrentHashMap<>();

    /** De onde o próximo projétil do jogador deve nascer (deslocamento a partir do olho), válido por poucos ticks. */
    private static class Origem {
        final Vec3d off;
        final int tick;
        Origem(Vec3d off, int tick) { this.off = off; this.tick = tick; }
    }
    private static final Map<UUID, Origem> origens = new ConcurrentHashMap<>();

    /** Usado pelo ProjectileEntityMixin. null = nascer normal. */
    public static Vec3d origemOffset(ServerPlayerEntity p) {
        Origem o = origens.get(p.getUuid());
        if (o == null || p.getServer() == null) return null;
        if (p.getServer().getTicks() - o.tick > 5) { origens.remove(p.getUuid()); return null; }
        return o.off;
    }

    @Override
    public void onInitialize() {
        MaosVrItens.registrar();

        // TP do modo mãos: o servidor confere tudo antes de teleportar
        ServerPlayNetworking.registerGlobalReceiver(MaosVrNet.TP, (server, player, handler, buf, sender) -> {
            double x = buf.readDouble(), y = buf.readDouble(), z = buf.readDouble();
            server.execute(() -> {
                if (player.isSpectator() || player.isDead()) return;
                int agora = server.getTicks();
                Integer ult = ultimoTp.get(player.getUuid());
                if (ult != null && agora - ult < 5) return;           // no máximo 1 TP a cada 5 ticks
                if (player.squaredDistanceTo(x, y, z) > TP_MAX * TP_MAX) return;
                ServerWorld w = (ServerWorld) player.world;
                BlockPos pe = new BlockPos((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
                if (!w.getWorldBorder().contains(pe) || !w.isChunkLoaded(pe)) return;
                BlockPos acima = pe.up();
                if (!w.getBlockState(pe).getCollisionShape(w, pe).isEmpty()) return;       // precisa caber em pé
                if (!w.getBlockState(acima).getCollisionShape(w, acima).isEmpty()) return;
                ultimoTp.put(player.getUuid(), agora);
                player.teleport(w, x, y, z, player.getYaw(), player.getPitch());
                player.fallDistance = 0;
                w.playSound(null, x, y, z, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.6f, 1.0f);
            });
        });

        // Projétil nasce na mão: o servidor confere que o ponto é perto do jogador e livre de blocos
        ServerPlayNetworking.registerGlobalReceiver(MaosVrNet.ORIGEM, (server, player, handler, buf, sender) -> {
            float ox = buf.readFloat(), oy = buf.readFloat(), oz = buf.readFloat();
            server.execute(() -> {
                if (!Float.isFinite(ox) || !Float.isFinite(oy) || !Float.isFinite(oz)) return;
                Vec3d off = new Vec3d(ox, oy, oz);
                if (off.length() > 2.0) { origens.remove(player.getUuid()); return; }
                Vec3d ponto = player.getEyePos().add(off);
                Box caixa = Box.of(ponto, 0.25, 0.25, 0.25);
                if (player.world.getBlockCollisions(player, caixa).iterator().hasNext()) {
                    origens.remove(player.getUuid());
                    return;
                }
                origens.put(player.getUuid(), new Origem(off, server.getTicks()));
            });
        });

        // Inclinar o corpo: o servidor confere (cabeça não atravessa bloco) e avisa todo mundo perto
        ServerPlayNetworking.registerGlobalReceiver(MaosVrNet.LEAN, (server, player, handler, buf, sender) -> {
            boolean ativo = buf.readBoolean();
            float lx = buf.readFloat(), lz = buf.readFloat();
            server.execute(() -> {
                if (!Float.isFinite(lx) || !Float.isFinite(lz)) return;
                float[] v = ativo ? MaosVrLean.validar(player.world, player, lx, lz, player.getYaw()) : new float[]{0f, 0f};

                // o dono mandou algo que o servidor não aceita: o servidor manda o valor certo de volta
                if (Math.abs(v[0] - lx) > 0.08 || Math.abs(v[1] - lz) > 0.08) {
                    PacketByteBuf ok = PacketByteBufs.create();
                    ok.writeFloat(v[0]);
                    ok.writeFloat(v[1]);
                    ServerPlayNetworking.send(player, MaosVrNet.LEAN_OK, ok);
                }

                for (ServerPlayerEntity outro : server.getPlayerManager().getPlayerList()) {
                    if (outro == player) continue;
                    if (outro.world != player.world) continue;
                    if (outro.squaredDistanceTo(player) > 128 * 128) continue;
                    if (!ServerPlayNetworking.canSend(outro, MaosVrNet.LEAN_PUB)) continue;
                    PacketByteBuf out = PacketByteBufs.create();
                    out.writeUuid(player.getUuid());
                    out.writeBoolean(ativo);
                    out.writeFloat(v[0]);
                    out.writeFloat(v[1]);
                    ServerPlayNetworking.send(outro, MaosVrNet.LEAN_PUB, out);
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(MaosVrNet.CANAL, (server, player, handler, buf, sender) -> {
            boolean ativo = buf.readBoolean();
            int ativa = buf.readByte();
            float a = buf.readFloat(), b = buf.readFloat(), c = buf.readFloat(), d = buf.readFloat();
            boolean painel = buf.readBoolean();          // inventário aberto na mão esquerda?
            int hover = buf.readByte();                   // slot que a mão direita está apontando (-1 = nenhum)
            boolean comItens = buf.readBoolean();         // veio a lista de itens junto?
            final int[] ids = new int[36];
            final byte[] qt = new byte[36];
            if (comItens) {
                for (int i = 0; i < 36; i++) { ids[i] = buf.readVarInt(); qt[i] = buf.readByte(); }
            }

            server.execute(() -> {
                for (ServerPlayerEntity outro : server.getPlayerManager().getPlayerList()) {
                    if (outro == player) continue;
                    if (outro.world != player.world) continue;
                    if (outro.squaredDistanceTo(player) > 128 * 128) continue;
                    if (!ServerPlayNetworking.canSend(outro, MaosVrNet.CANAL)) continue;

                    PacketByteBuf out = PacketByteBufs.create();
                    out.writeUuid(player.getUuid());
                    out.writeBoolean(ativo);
                    out.writeByte(ativa);
                    out.writeFloat(a);
                    out.writeFloat(b);
                    out.writeFloat(c);
                    out.writeFloat(d);
                    out.writeBoolean(painel);
                    out.writeByte(hover);
                    out.writeBoolean(comItens);
                    if (comItens) {
                        for (int i = 0; i < 36; i++) { out.writeVarInt(ids[i]); out.writeByte(qt[i]); }
                    }
                    ServerPlayNetworking.send(outro, MaosVrNet.CANAL, out);
                }
            });
        });
    }
}
